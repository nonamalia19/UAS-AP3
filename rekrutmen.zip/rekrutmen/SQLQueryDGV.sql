-- ini kan query saat ini
select * from divisi
--seakrang kita ganti dengan call per fiesldnya
--nama alias ini bebas
Select T0.kd_divisi As [Kode Divisi],T0.nm_divisi As [Nama Divisi],T0.Jabatan From divisi T0

--jadi bedakan

select * from jabatan

select T0.Kd_jabatan as [ Kode Jabatan ], t0.Nm_jabatan as [ Nama Jabatan ] from jabatan t0
----------------------------------------------------------------------------------------------------------------------
select * from users

select t0.id_user as [ ID User ], t0.nm_user as [ Nama User ], t0.pass as [ Password ], t0.UserName from users t0
----------------------------------------------------------------------------------------------------------------------
use master_rekrutmen

select * from Kandidat

select t0.id_kandidat as [ ID Kandidat ], t0.nm_kandidat as [ Nama Kandidat ], t0.tmp_lhr as [ Tempat Lahir ], t0.tgl_lhr as [ Tanggal Lahir ], t0.agama as [ Agama ], t0.pendidikan as [ Pendidikan ], t0.j_kelamin as [ Jenis Kelamin ], t0.no_ktp as [ Nomor KTP ], t0.alamat as [ Alamat ], t0.no_tlp as [ Nomor Telepon ], t0.no_rek as [ Nomor Rekening ], t0.no_bpjstk as [ Nomor BPJS TK ],
t0.no_npwp as [ Nomor NPWP ], t0.masaberlaku_ktp as [ Masa Berlaku KTP ], t0.tgl_masuk as [ Tanggal Masuk ], t0.tenaga_kerja as [ Tenaga Kerja ], t0.area_penempatan as [ Area Penempatan ], t0.kd_jabatan as [ Kode Jabatan ], t0.kd_divisi as [ Kode Divisi ], t0.status_kandidat as [ Status Kandidat ], t0.id_lowongan as [ ID Lowongan ], t0.Status_Pernikahan as [ Status Pernikahan ] from Kandidat t0

