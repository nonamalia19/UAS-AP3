﻿Module GlobalVariabel
    Public kd_jabatan As String
    Public kd_divisi As String
    Public id_kandidat As String
    Public FlagSimpanUpdate As String
    Public id_lowongan As String
    Public id_seleksi As String
    Public id_user As String
    'ini baru buat baca flag menu
    Public MenuKandidat As String
    Public MenuSeleksi As String
    Public MenuDivisi As String
    Public MenuJabatan As String
    Public MenuUsers As String
    Public MenuLowongan As String
    Public MenuUtility As String
End Module
