﻿Imports System.Data.SqlClient

Public Class ConnectionSQL
    Dim da As SqlDataAdapter
    Dim ds As DataSet
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Dim conn As SqlConnection
    Dim iduser As String
    Dim strConn As String = My.Settings.StringConn.Trim()



    '----------------------------------------------------------------------------------
    Public Function bukaTable(ByVal q As String) As DataTable
        conn = New SqlConnection(strConn)
        conn.Open()
        Try
            cmd = New SqlCommand(q, conn)
            dr = cmd.ExecuteReader()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
        Dim dt As New DataTable
        dt.Load(dr)
        dr.Close()
        conn.Close()

        Return dt
    End Function
    '-----------------------------------------------------------------------------------
    Public Function jalankanQuery(ByVal q As String) As Boolean
        conn = New SqlConnection(strConn)
        conn.Open()
        Try
            cmd = New SqlCommand(q, conn)
            cmd.ExecuteNonQuery()
            conn.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

        Return True
    End Function

End Class
