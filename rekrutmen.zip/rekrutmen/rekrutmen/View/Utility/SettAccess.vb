﻿
Public Class SettAccess
    Dim ctrl As New CtrlUsers
    Private Sub SettAccess_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ctrl.tampilDataAcces(DGV)
    End Sub

    Private Sub DGV_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DGV.CellClick
        If DGV.Rows.Count > 0 Then
            kd_divisi = DGV.CurrentRow.Cells(0).Value.ToString
            If (kd_divisi.Trim <> "") Then
                If DGV.CurrentCell.ColumnIndex = 2 Or DGV.CurrentCell.ColumnIndex = 3 Or DGV.CurrentCell.ColumnIndex = 4 Or DGV.CurrentCell.ColumnIndex = 5 Or DGV.CurrentCell.ColumnIndex = 6 Or DGV.CurrentCell.ColumnIndex = 7 Or DGV.CurrentCell.ColumnIndex = 8 Then
                    Dim TheValue As String = DGV.CurrentCell.Value.ToString()
                    If TheValue.Trim() = "False" Or TheValue.Trim() = "" Then
                        TheValue = "True"
                        DGV.CurrentCell.Value = True
                        ctrl.EditDataAccess(kd_divisi, Convert.ToInt32(DGV.CurrentCell.ColumnIndex), TheValue)
                    Else
                        TheValue = "False"
                        DGV.CurrentCell.Value = False
                        ctrl.EditDataAccess(kd_divisi, Convert.ToInt32(DGV.CurrentCell.ColumnIndex), TheValue)
                    End If

                End If
            End If
        End If
    End Sub

End Class