﻿

Public Class KandidatForm
    Dim result As Boolean
    Dim kdt As New EntKandidat
    Dim hisKel As New Enthistory_keluarga
    Dim hisHubKel As New Enthistori_hubkel
    Dim ctrlKand As New CtrlKandidat
    Dim ctrlHisKel As New CtrlHisKeluarga
    Dim ctrlHisHubKel As New CtrlHisHubKeluarga
    Private Sub SetSimpanKandidat()
        Try
            'Tab1
            kdt.IDKandidat = TxtKode.Text
            kdt.NamaKandidat = TxtNama.Text
            kdt.StatusKandidat = ComboStatuskand.Text
            kdt.TglMasuk = DateTimePickerJoin.Value.ToString("MM/dd/yyyy")
            kdt.TmpatLahir = txttmplhr.Text
            kdt.TanggalLhr = DateTimeTglLahir.Value.ToString("MM/dd/yyyy")
            kdt.AgamaKdt = ComboBoxAgama.Text
            kdt.JenisKelamin = ComboBoxJenisKl.Text
            kdt.NoKtp = txtnoktp.Text
            kdt.AlamatKandidat = txtalamat.Text
            kdt.NoTelp = txtnotlp.Text
            kdt.PendidikanKdt = txtpendidikan.Text
            kdt.StatusKawin = ComboBoxKawin.Text
            kdt.KodeJabatan = ComboKdJabatan.Text
            kdt.KodeDivisi = ComboKdDivisi.Text
            kdt.NoNpwp = txtnonpwp.Text
            kdt.NoBpjs = txtnobpjs.Text
            kdt.NoRek = txtnorek.Text
            kdt.MassaKtp = txtMasaBerlakuktp.Text
            kdt.TenagaKerja = ComboBoxTenagaKerja.Text
            kdt.AreaPenempatan = txtareaPenemp.Text
            'Tab2
            hisKel.IDKandidat = TxtKode.Text
            'hisKel.IDHiskel = TxtKode.Text
            hisKel.NamaIstriAtuSuami = txtNamaSuIs.Text
            hisKel.NamaAnak1 = TxtNamaAnak1.Text
            hisKel.NamaAnak2 = TxtNamaAnak2.Text
            hisKel.NamaAnak3 = TxtNamaAnak3.Text
            hisKel.UsiaIstriSuami = TxtUsiaSuIs.Text
            hisKel.UsiaAnak1 = TxtUsiaAnak1.Text
            hisKel.UsiaAnak2 = TxtUsiaAnak2.Text
            hisKel.UsiaAnak3 = TxtUsiaAnak3.Text
            hisKel.PendidikanIstriSuami = TxtPendidikanSuIs.Text
            hisKel.PendidikanAnak1 = TxtPendidikanAnak1.Text
            hisKel.PendidikanAnak2 = TxtPendidikanAnak2.Text
            hisKel.PendidikanAnak3 = TxtPendidikanAnak3.Text
            hisKel.PekertjaanIstriSuami = TxtPkerjaanSuIs.Text
            hisKel.PekerjaanAnak1 = TxtPekerjaanAnak1.Text
            hisKel.PekerjaanAnak2 = TxtPekerjaanAnak2.Text
            hisKel.PekerjaanAnak3 = TxtPekerjaanAnak3.Text
            'Tab 3
            hisHubKel.IDKandidat = TxtKode.Text
            hisHubKel.NamaAyah = txtNamaAyah.Text
            hisHubKel.NamaIbu = TxtNamaIbu.Text
            hisHubKel.NamaSodara1 = txtNamaSdr1.Text
            hisHubKel.NamaSodara2 = txtNamaSdr2.Text
            hisHubKel.NamaSodara3 = txtNamaSdr3.Text
            hisHubKel.UsiaAyah = txtUsiaAyah.Text
            hisHubKel.UsiaIbu = txtUsiaIbu.Text
            hisHubKel.UsiaSDR1 = txtUsiaSdr1.Text
            hisHubKel.UsiaSDR2 = txtUsiaSdr2.Text
            hisHubKel.UsiaSDR3 = txtUsiaSdr3.Text
            hisHubKel.PedidikanAyah = txtPendidikanAyah.Text
            hisHubKel.PendidikanIbu = txtPendidikanIbu.Text
            hisHubKel.PendidikanSDR1 = txtPendidikanSdr1.Text
            hisHubKel.PendidikanSDR2 = txtPendidikanSdr2.Text
            hisHubKel.PendidikanSDR3 = txtPendidikanSdr3.Text
            hisHubKel.PekerjaanAyah = txtPekerjaanAyah.Text
            hisHubKel.PekerjaanIbu = txtPekerjaanIbu.Text
            hisHubKel.PekerjaanSDR1 = txtPekerjaanSdr1.Text
            hisHubKel.PekerjaanSDR2 = txtPekerjaanSdr2.Text
            hisHubKel.PekerjaanSDR3 = txtPekerjaanSdr3.Text


        Catch ex As Exception
            MessageBox.Show(ex.ToString())
            Return
        End Try

    End Sub

    Private Sub SetTampilkanDataUpdate()
        Try
            'Tab1
            TxtKode.Text = kdt.IDKandidat.Trim()
            TxtKode.Enabled = False
            TxtNama.Text = kdt.NamaKandidat.Trim()
            txttmplhr.Text = kdt.TmpatLahir.Trim()
            DateTimeTglLahir.Text = kdt.TanggalLhr.Trim()
            txtpendidikan.Text = kdt.PendidikanKdt.Trim()
            txtnoktp.Text = kdt.NoKtp.Trim()
            txtalamat.Text = kdt.AlamatKandidat.Trim()
            txtnotlp.Text = kdt.NoTelp.Trim()
            txtnorek.Text = kdt.NoRek.Trim()
            txtnobpjs.Text = kdt.NoBpjs.Trim()
            txtnonpwp.Text = kdt.NoNpwp.Trim()
            txtMasaBerlakuktp.Text = kdt.MassaKtp.Trim()
            DateTimePickerJoin.Text = kdt.TglMasuk.Trim()
            txtareaPenemp.Text = kdt.AreaPenempatan.Trim()
            ComboBoxJenisKl.Text = kdt.JenisKelamin.Trim()
            ComboKdJabatan.Text = kdt.KodeJabatan.Trim()
            ComboKdDivisi.Text = kdt.KodeDivisi.Trim()
            ComboBoxAgama.Text = kdt.AgamaKdt.ToString().Trim()
            ComboBoxTenagaKerja.Text = kdt.TenagaKerja.Trim()
            ComboStatuskand.Text = kdt.StatusKandidat.Trim()
            ComboBoxKawin.Text = kdt.StatusKawin.Trim()
            'Tab 2

            txtNamaSuIs.Text = hisKel.NamaIstriAtuSuami
            TxtNamaAnak1.Text = hisKel.NamaAnak1
            TxtNamaAnak2.Text = hisKel.NamaAnak2
            TxtNamaAnak3.Text = hisKel.NamaAnak3
            TxtUsiaSuIs.Text = hisKel.UsiaIstriSuami
            TxtUsiaAnak1.Text = hisKel.UsiaAnak1
            TxtUsiaAnak2.Text = hisKel.UsiaAnak2
            TxtUsiaAnak3.Text = hisKel.UsiaAnak3
            TxtPendidikanSuIs.Text = hisKel.PendidikanIstriSuami
            TxtPendidikanAnak1.Text = hisKel.PendidikanAnak1
            TxtPendidikanAnak2.Text = hisKel.PendidikanAnak2
            TxtPendidikanAnak3.Text = hisKel.PendidikanAnak3
            TxtPkerjaanSuIs.Text = hisKel.PekertjaanIstriSuami
            TxtPekerjaanAnak1.Text = hisKel.PekerjaanAnak1
            TxtPekerjaanAnak2.Text = hisKel.PekerjaanAnak2
            TxtPekerjaanAnak3.Text = hisKel.PekerjaanAnak3

            'Tab 3
            txtNamaAyah.Text = hisHubKel.NamaAyah
            TxtNamaIbu.Text = hisHubKel.NamaIbu
            txtNamaSdr1.Text = hisHubKel.NamaSodara1
            txtNamaSdr2.Text = hisHubKel.NamaSodara2
            txtNamaSdr3.Text = hisHubKel.NamaSodara3
            txtUsiaAyah.Text = hisHubKel.UsiaAyah
            txtUsiaIbu.Text = hisHubKel.UsiaIbu
            txtUsiaSdr1.Text = hisHubKel.UsiaSDR1
            txtUsiaSdr2.Text = hisHubKel.UsiaSDR2
            txtUsiaSdr3.Text = hisHubKel.UsiaSDR3
            txtPendidikanAyah.Text = hisHubKel.PedidikanAyah
            txtPendidikanIbu.Text = hisHubKel.PendidikanIbu
            txtPendidikanSdr1.Text = hisHubKel.PendidikanSDR1
            txtPendidikanSdr2.Text = hisHubKel.PendidikanSDR2
            txtPendidikanSdr3.Text = hisHubKel.PendidikanSDR3
            txtPekerjaanAyah.Text = hisHubKel.PekerjaanAyah
            txtPekerjaanIbu.Text = hisHubKel.PekerjaanIbu
            txtPekerjaanSdr1.Text = hisHubKel.PekerjaanSDR1
            txtPekerjaanSdr2.Text = hisHubKel.PekerjaanSDR2
            txtPekerjaanSdr3.Text = hisHubKel.PekerjaanSDR3
        Catch ex As Exception
            MessageBox.Show(ex.ToString())
            Return
        End Try
    End Sub

    Private Sub btnsimpan_Click(sender As Object, e As EventArgs) Handles btnsimpan.Click

        If ComboBoxKawin.Text.ToUpper().Trim() = "KAWIN" Then
            If txtNamaSuIs.Text.Trim() = "" Then
                MessageBox.Show("Silahkan lengkapi data suami/istri pada tab data keluarga jika status perkawinan anda = Kawin")
                Return
            End If
        End If

        If ComboBoxKawin.Text.ToUpper().Trim() = "BELUM KAWIN" Then
            If txtNamaAyah.Text.Trim() = "" Then
                MessageBox.Show("Silakan Lengkapi Data Keluarga pada Tab Data Keluarga Jika Status Perkawinan Anda = Tidak Kawin")
                Return
            End If
        End If

        SetSimpanKandidat()
        If FlagSimpanUpdate.ToUpper().Trim() = "ADD" Then
            If (ctrlKand.TambahDataKandidat(kdt)) Then
                If (ctrlHisKel.TambahDataHistory(hisKel)) Then
                    If (ctrlHisHubKel.TambahDataHistoryHubkel(hisHubKel)) Then
                        result = True
                    End If
                End If
            End If
        ElseIf FlagSimpanUpdate.ToUpper().Trim() = "UPDATE" Then
            If ctrlKand.editData(kdt) Then
                If ctrlHisKel.editData(hisKel) Then
                    If ctrlHisHubKel.editData(hisHubKel) Then
                        result = True
                    End If
                End If
            End If
        End If

        If result = True Then
            Me.Dispose()
            ListKandidat.Focus()
        End If
    End Sub
    Private Sub SetValueComboJabatan(ByVal obj As ComboBox)
        ctrlKand.GetValueComboJabatan(obj)
    End Sub
    Private Sub SetValueComboDivisi(ByVal obj As ComboBox)
        ctrlKand.GetValueComboDivisi(obj)
    End Sub
    Private Sub SetIDKandidat()
        TxtKode.Text = ctrlKand.SetKodeKandidat()
        TxtKode.Enabled = False
    End Sub
    Private Sub KandidatForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If FlagSimpanUpdate.ToUpper().Trim() = "ADD" Then
            SetIDKandidat()
            SetValueComboJabatan(ComboKdJabatan)
            SetValueComboDivisi(ComboKdDivisi)
        ElseIf FlagSimpanUpdate.ToUpper().Trim() = "UPDATE" Then
            kdt = ctrlKand.cariDataBykode(id_kandidat)
            hisKel = ctrlHisKel.cariDataBykode(id_kandidat)
            hisHubKel = ctrlHisHubKel.cariDataBykode(id_kandidat)
            SetValueComboJabatan(ComboKdJabatan)
            SetValueComboDivisi(ComboKdDivisi)
            SetTampilkanDataUpdate()
        End If
    End Sub

    Private Sub Btnbatal_Click(sender As Object, e As EventArgs) Handles Btnbatal.Click
        Me.Close()
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        txtMasaBerlakuktp.Text = "Seumur Hidup"
    End Sub

    Private Sub Label17_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub TabPageDdiri_Click(sender As Object, e As EventArgs) Handles TabPageDdiri.Click

    End Sub
End Class