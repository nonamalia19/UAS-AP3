﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class KandidatForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(KandidatForm))
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPageDdiri = New System.Windows.Forms.TabPage()
        Me.Btnbatal = New System.Windows.Forms.Button()
        Me.btnsimpan = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.txtMasaBerlakuktp = New System.Windows.Forms.TextBox()
        Me.ComboBoxTenagaKerja = New System.Windows.Forms.ComboBox()
        Me.ComboKdDivisi = New System.Windows.Forms.ComboBox()
        Me.ComboKdJabatan = New System.Windows.Forms.ComboBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.txtnorek = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.txtareaPenemp = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtnonpwp = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.txtnobpjs = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.DateTimePickerJoin = New System.Windows.Forms.DateTimePicker()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.ComboStatuskand = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TxtNama = New System.Windows.Forms.TextBox()
        Me.TxtKode = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.ComboBoxJenisKl = New System.Windows.Forms.ComboBox()
        Me.ComboBoxAgama = New System.Windows.Forms.ComboBox()
        Me.ComboBoxKawin = New System.Windows.Forms.ComboBox()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtpendidikan = New System.Windows.Forms.TextBox()
        Me.txtnotlp = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtalamat = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtnoktp = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.DateTimeTglLahir = New System.Windows.Forms.DateTimePicker()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txttmplhr = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TabPageDKel1 = New System.Windows.Forms.TabPage()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.TxtUsiaAnak3 = New System.Windows.Forms.TextBox()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.TxtUsiaAnak2 = New System.Windows.Forms.TextBox()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.TxtUsiaAnak1 = New System.Windows.Forms.TextBox()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.TxtUsiaSuIs = New System.Windows.Forms.TextBox()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.GroupBox10 = New System.Windows.Forms.GroupBox()
        Me.TxtPekerjaanAnak3 = New System.Windows.Forms.TextBox()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.TxtPekerjaanAnak2 = New System.Windows.Forms.TextBox()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.TxtPekerjaanAnak1 = New System.Windows.Forms.TextBox()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.TxtPkerjaanSuIs = New System.Windows.Forms.TextBox()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.TxtPendidikanAnak3 = New System.Windows.Forms.TextBox()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.TxtPendidikanAnak2 = New System.Windows.Forms.TextBox()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.TxtPendidikanAnak1 = New System.Windows.Forms.TextBox()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.TxtPendidikanSuIs = New System.Windows.Forms.TextBox()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.TxtNamaAnak3 = New System.Windows.Forms.TextBox()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.TxtNamaAnak2 = New System.Windows.Forms.TextBox()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.TxtNamaAnak1 = New System.Windows.Forms.TextBox()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.txtNamaSuIs = New System.Windows.Forms.TextBox()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.TabPageDkel2 = New System.Windows.Forms.TabPage()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.txtUsiaSdr3 = New System.Windows.Forms.TextBox()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.txtUsiaSdr2 = New System.Windows.Forms.TextBox()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.txtUsiaSdr1 = New System.Windows.Forms.TextBox()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.txtUsiaIbu = New System.Windows.Forms.TextBox()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.txtUsiaAyah = New System.Windows.Forms.TextBox()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.txtPekerjaanSdr3 = New System.Windows.Forms.TextBox()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.txtPekerjaanSdr2 = New System.Windows.Forms.TextBox()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.txtPekerjaanSdr1 = New System.Windows.Forms.TextBox()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.txtPekerjaanIbu = New System.Windows.Forms.TextBox()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.txtPekerjaanAyah = New System.Windows.Forms.TextBox()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.txtPendidikanSdr3 = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.txtPendidikanSdr2 = New System.Windows.Forms.TextBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.txtPendidikanSdr1 = New System.Windows.Forms.TextBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.txtPendidikanIbu = New System.Windows.Forms.TextBox()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.txtPendidikanAyah = New System.Windows.Forms.TextBox()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.txtNamaSdr3 = New System.Windows.Forms.TextBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.txtNamaSdr2 = New System.Windows.Forms.TextBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.txtNamaSdr1 = New System.Windows.Forms.TextBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.TxtNamaIbu = New System.Windows.Forms.TextBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.txtNamaAyah = New System.Windows.Forms.TextBox()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.TabControl1.SuspendLayout()
        Me.TabPageDdiri.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.TabPageDKel1.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        Me.GroupBox10.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.TabPageDkel2.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPageDdiri)
        Me.TabControl1.Controls.Add(Me.TabPageDKel1)
        Me.TabControl1.Controls.Add(Me.TabPageDkel2)
        Me.TabControl1.Location = New System.Drawing.Point(1, 0)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1039, 428)
        Me.TabControl1.TabIndex = 0
        '
        'TabPageDdiri
        '
        Me.TabPageDdiri.BackColor = System.Drawing.Color.Teal
        Me.TabPageDdiri.Controls.Add(Me.Btnbatal)
        Me.TabPageDdiri.Controls.Add(Me.btnsimpan)
        Me.TabPageDdiri.Controls.Add(Me.GroupBox2)
        Me.TabPageDdiri.Controls.Add(Me.DateTimePickerJoin)
        Me.TabPageDdiri.Controls.Add(Me.Label4)
        Me.TabPageDdiri.Controls.Add(Me.ComboStatuskand)
        Me.TabPageDdiri.Controls.Add(Me.Label2)
        Me.TabPageDdiri.Controls.Add(Me.Label1)
        Me.TabPageDdiri.Controls.Add(Me.Label3)
        Me.TabPageDdiri.Controls.Add(Me.TxtNama)
        Me.TabPageDdiri.Controls.Add(Me.TxtKode)
        Me.TabPageDdiri.Controls.Add(Me.GroupBox1)
        Me.TabPageDdiri.Location = New System.Drawing.Point(4, 22)
        Me.TabPageDdiri.Name = "TabPageDdiri"
        Me.TabPageDdiri.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPageDdiri.Size = New System.Drawing.Size(1031, 402)
        Me.TabPageDdiri.TabIndex = 0
        Me.TabPageDdiri.Text = "Data Diri"
        '
        'Btnbatal
        '
        Me.Btnbatal.BackgroundImage = CType(resources.GetObject("Btnbatal.BackgroundImage"), System.Drawing.Image)
        Me.Btnbatal.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btnbatal.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btnbatal.Location = New System.Drawing.Point(896, 360)
        Me.Btnbatal.Name = "Btnbatal"
        Me.Btnbatal.Size = New System.Drawing.Size(110, 29)
        Me.Btnbatal.TabIndex = 116
        Me.Btnbatal.Text = "Batal"
        '
        'btnsimpan
        '
        Me.btnsimpan.BackgroundImage = CType(resources.GetObject("btnsimpan.BackgroundImage"), System.Drawing.Image)
        Me.btnsimpan.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnsimpan.Location = New System.Drawing.Point(7, 360)
        Me.btnsimpan.Name = "btnsimpan"
        Me.btnsimpan.Size = New System.Drawing.Size(110, 29)
        Me.btnsimpan.TabIndex = 115
        Me.btnsimpan.Text = "Simpan"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.CheckBox1)
        Me.GroupBox2.Controls.Add(Me.txtMasaBerlakuktp)
        Me.GroupBox2.Controls.Add(Me.ComboBoxTenagaKerja)
        Me.GroupBox2.Controls.Add(Me.ComboKdDivisi)
        Me.GroupBox2.Controls.Add(Me.ComboKdJabatan)
        Me.GroupBox2.Controls.Add(Me.Label22)
        Me.GroupBox2.Controls.Add(Me.Label19)
        Me.GroupBox2.Controls.Add(Me.Label20)
        Me.GroupBox2.Controls.Add(Me.Label21)
        Me.GroupBox2.Controls.Add(Me.txtnorek)
        Me.GroupBox2.Controls.Add(Me.Label14)
        Me.GroupBox2.Controls.Add(Me.txtareaPenemp)
        Me.GroupBox2.Controls.Add(Me.Label13)
        Me.GroupBox2.Controls.Add(Me.txtnonpwp)
        Me.GroupBox2.Controls.Add(Me.Label15)
        Me.GroupBox2.Controls.Add(Me.txtnobpjs)
        Me.GroupBox2.Controls.Add(Me.Label16)
        Me.GroupBox2.Location = New System.Drawing.Point(545, 70)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(461, 284)
        Me.GroupBox2.TabIndex = 114
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Data Pajak"
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Location = New System.Drawing.Point(305, 167)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox1.TabIndex = 137
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'txtMasaBerlakuktp
        '
        Me.txtMasaBerlakuktp.Location = New System.Drawing.Point(146, 164)
        Me.txtMasaBerlakuktp.Name = "txtMasaBerlakuktp"
        Me.txtMasaBerlakuktp.Size = New System.Drawing.Size(153, 20)
        Me.txtMasaBerlakuktp.TabIndex = 136
        '
        'ComboBoxTenagaKerja
        '
        Me.ComboBoxTenagaKerja.AutoCompleteCustomSource.AddRange(New String() {"Probation", "Kontrak"})
        Me.ComboBoxTenagaKerja.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxTenagaKerja.FormattingEnabled = True
        Me.ComboBoxTenagaKerja.Items.AddRange(New Object() {"Probation", "Kontrak"})
        Me.ComboBoxTenagaKerja.Location = New System.Drawing.Point(146, 190)
        Me.ComboBoxTenagaKerja.Name = "ComboBoxTenagaKerja"
        Me.ComboBoxTenagaKerja.Size = New System.Drawing.Size(174, 21)
        Me.ComboBoxTenagaKerja.TabIndex = 135
        '
        'ComboKdDivisi
        '
        Me.ComboKdDivisi.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboKdDivisi.FormattingEnabled = True
        Me.ComboKdDivisi.Location = New System.Drawing.Point(146, 61)
        Me.ComboKdDivisi.Name = "ComboKdDivisi"
        Me.ComboKdDivisi.Size = New System.Drawing.Size(174, 21)
        Me.ComboKdDivisi.TabIndex = 134
        '
        'ComboKdJabatan
        '
        Me.ComboKdJabatan.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboKdJabatan.FormattingEnabled = True
        Me.ComboKdJabatan.Location = New System.Drawing.Point(146, 37)
        Me.ComboKdJabatan.Name = "ComboKdJabatan"
        Me.ComboKdJabatan.Size = New System.Drawing.Size(174, 21)
        Me.ComboKdJabatan.TabIndex = 133
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.ForeColor = System.Drawing.Color.Black
        Me.Label22.Location = New System.Drawing.Point(13, 61)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(76, 16)
        Me.Label22.TabIndex = 128
        Me.Label22.Text = "Kode Divisi"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.Black
        Me.Label19.Location = New System.Drawing.Point(12, 217)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(117, 16)
        Me.Label19.TabIndex = 129
        Me.Label19.Text = "Area Penempatan"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.ForeColor = System.Drawing.Color.Black
        Me.Label20.Location = New System.Drawing.Point(13, 37)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(92, 16)
        Me.Label20.TabIndex = 131
        Me.Label20.Text = "Kode Jabatan"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.ForeColor = System.Drawing.Color.Black
        Me.Label21.Location = New System.Drawing.Point(13, 194)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(90, 16)
        Me.Label21.TabIndex = 127
        Me.Label21.Text = "Tenaga Kerja"
        '
        'txtnorek
        '
        Me.txtnorek.Location = New System.Drawing.Point(146, 138)
        Me.txtnorek.Name = "txtnorek"
        Me.txtnorek.Size = New System.Drawing.Size(174, 20)
        Me.txtnorek.TabIndex = 126
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.Black
        Me.Label14.Location = New System.Drawing.Point(13, 168)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(113, 16)
        Me.Label14.TabIndex = 121
        Me.Label14.Text = "Masa Berlaku Ktp"
        '
        'txtareaPenemp
        '
        Me.txtareaPenemp.Location = New System.Drawing.Point(146, 216)
        Me.txtareaPenemp.Name = "txtareaPenemp"
        Me.txtareaPenemp.Size = New System.Drawing.Size(174, 20)
        Me.txtareaPenemp.TabIndex = 120
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.Black
        Me.Label13.Location = New System.Drawing.Point(13, 90)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(64, 16)
        Me.Label13.TabIndex = 119
        Me.Label13.Text = "No.Npwp"
        '
        'txtnonpwp
        '
        Me.txtnonpwp.Location = New System.Drawing.Point(146, 86)
        Me.txtnonpwp.Name = "txtnonpwp"
        Me.txtnonpwp.Size = New System.Drawing.Size(174, 20)
        Me.txtnonpwp.TabIndex = 118
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.Black
        Me.Label15.Location = New System.Drawing.Point(13, 113)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(76, 16)
        Me.Label15.TabIndex = 117
        Me.Label15.Text = "No.Bpjs TK"
        '
        'txtnobpjs
        '
        Me.txtnobpjs.Location = New System.Drawing.Point(146, 112)
        Me.txtnobpjs.Name = "txtnobpjs"
        Me.txtnobpjs.Size = New System.Drawing.Size(174, 20)
        Me.txtnobpjs.TabIndex = 116
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.Black
        Me.Label16.Location = New System.Drawing.Point(13, 142)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(87, 16)
        Me.Label16.TabIndex = 115
        Me.Label16.Text = "No.Rekening"
        '
        'DateTimePickerJoin
        '
        Me.DateTimePickerJoin.Location = New System.Drawing.Point(545, 8)
        Me.DateTimePickerJoin.Name = "DateTimePickerJoin"
        Me.DateTimePickerJoin.Size = New System.Drawing.Size(174, 20)
        Me.DateTimePickerJoin.TabIndex = 99
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(409, 3)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(65, 16)
        Me.Label4.TabIndex = 97
        Me.Label4.Text = "Join Date"
        '
        'ComboStatuskand
        '
        Me.ComboStatuskand.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboStatuskand.FormattingEnabled = True
        Me.ComboStatuskand.Items.AddRange(New Object() {"Interview", "Psikotes", "User Interview"})
        Me.ComboStatuskand.Location = New System.Drawing.Point(545, 33)
        Me.ComboStatuskand.Name = "ComboStatuskand"
        Me.ComboStatuskand.Size = New System.Drawing.Size(174, 21)
        Me.ComboStatuskand.TabIndex = 96
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(409, 35)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(101, 16)
        Me.Label2.TabIndex = 94
        Me.Label2.Text = "Status Kandidat"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(6, 35)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(101, 16)
        Me.Label1.TabIndex = 93
        Me.Label1.Text = "Nama Kandidat"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(6, 12)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(77, 16)
        Me.Label3.TabIndex = 92
        Me.Label3.Text = "ID Kandidat"
        '
        'TxtNama
        '
        Me.TxtNama.Location = New System.Drawing.Point(136, 34)
        Me.TxtNama.Name = "TxtNama"
        Me.TxtNama.Size = New System.Drawing.Size(200, 20)
        Me.TxtNama.TabIndex = 91
        '
        'TxtKode
        '
        Me.TxtKode.Location = New System.Drawing.Point(136, 8)
        Me.TxtKode.Name = "TxtKode"
        Me.TxtKode.Size = New System.Drawing.Size(79, 20)
        Me.TxtKode.TabIndex = 90
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.ComboBoxJenisKl)
        Me.GroupBox1.Controls.Add(Me.ComboBoxAgama)
        Me.GroupBox1.Controls.Add(Me.ComboBoxKawin)
        Me.GroupBox1.Controls.Add(Me.Label47)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.txtpendidikan)
        Me.GroupBox1.Controls.Add(Me.txtnotlp)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.txtalamat)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.txtnoktp)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.DateTimeTglLahir)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.txttmplhr)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Location = New System.Drawing.Point(6, 70)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(468, 284)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Data Diri"
        '
        'ComboBoxJenisKl
        '
        Me.ComboBoxJenisKl.AutoCompleteCustomSource.AddRange(New String() {"Kawin", "Belum Tidak "})
        Me.ComboBoxJenisKl.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxJenisKl.FormattingEnabled = True
        Me.ComboBoxJenisKl.Items.AddRange(New Object() {"Laki-Laki", "Perempuan"})
        Me.ComboBoxJenisKl.Location = New System.Drawing.Point(130, 93)
        Me.ComboBoxJenisKl.Name = "ComboBoxJenisKl"
        Me.ComboBoxJenisKl.Size = New System.Drawing.Size(200, 21)
        Me.ComboBoxJenisKl.TabIndex = 136
        '
        'ComboBoxAgama
        '
        Me.ComboBoxAgama.AutoCompleteCustomSource.AddRange(New String() {"Kawin", "Belum Tidak "})
        Me.ComboBoxAgama.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxAgama.FormattingEnabled = True
        Me.ComboBoxAgama.Items.AddRange(New Object() {"Islam", "Kristen Protestan", "Katolik", "Hindu", "Budha", "Kong hu cu"})
        Me.ComboBoxAgama.Location = New System.Drawing.Point(130, 68)
        Me.ComboBoxAgama.Name = "ComboBoxAgama"
        Me.ComboBoxAgama.Size = New System.Drawing.Size(200, 21)
        Me.ComboBoxAgama.TabIndex = 135
        '
        'ComboBoxKawin
        '
        Me.ComboBoxKawin.AutoCompleteCustomSource.AddRange(New String() {"Kawin", "Belum Tidak "})
        Me.ComboBoxKawin.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxKawin.FormattingEnabled = True
        Me.ComboBoxKawin.Items.AddRange(New Object() {"Kawin", "Belum Kawin"})
        Me.ComboBoxKawin.Location = New System.Drawing.Point(130, 217)
        Me.ComboBoxKawin.Name = "ComboBoxKawin"
        Me.ComboBoxKawin.Size = New System.Drawing.Size(200, 21)
        Me.ComboBoxKawin.TabIndex = 134
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label47.ForeColor = System.Drawing.Color.Black
        Me.Label47.Location = New System.Drawing.Point(10, 223)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(118, 16)
        Me.Label47.TabIndex = 130
        Me.Label47.Text = "Status Perkawinan"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.Black
        Me.Label12.Location = New System.Drawing.Point(10, 193)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(76, 16)
        Me.Label12.TabIndex = 101
        Me.Label12.Text = "Pendidikan"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.Black
        Me.Label10.Location = New System.Drawing.Point(10, 168)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(49, 16)
        Me.Label10.TabIndex = 113
        Me.Label10.Text = "No.Tlp"
        '
        'txtpendidikan
        '
        Me.txtpendidikan.Location = New System.Drawing.Point(130, 193)
        Me.txtpendidikan.Name = "txtpendidikan"
        Me.txtpendidikan.Size = New System.Drawing.Size(200, 20)
        Me.txtpendidikan.TabIndex = 100
        '
        'txtnotlp
        '
        Me.txtnotlp.Location = New System.Drawing.Point(130, 168)
        Me.txtnotlp.Name = "txtnotlp"
        Me.txtnotlp.Size = New System.Drawing.Size(200, 20)
        Me.txtnotlp.TabIndex = 112
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Black
        Me.Label9.Location = New System.Drawing.Point(10, 142)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(50, 16)
        Me.Label9.TabIndex = 111
        Me.Label9.Text = "Alamat"
        '
        'txtalamat
        '
        Me.txtalamat.Location = New System.Drawing.Point(130, 143)
        Me.txtalamat.Name = "txtalamat"
        Me.txtalamat.Size = New System.Drawing.Size(200, 20)
        Me.txtalamat.TabIndex = 110
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(10, 116)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(48, 16)
        Me.Label8.TabIndex = 109
        Me.Label8.Text = "No.Ktp"
        '
        'txtnoktp
        '
        Me.txtnoktp.Location = New System.Drawing.Point(130, 117)
        Me.txtnoktp.Name = "txtnoktp"
        Me.txtnoktp.Size = New System.Drawing.Size(200, 20)
        Me.txtnoktp.TabIndex = 108
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.Black
        Me.Label11.Location = New System.Drawing.Point(10, 92)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(91, 16)
        Me.Label11.TabIndex = 107
        Me.Label11.Text = "Jenis Kelamin"
        '
        'DateTimeTglLahir
        '
        Me.DateTimeTglLahir.Location = New System.Drawing.Point(130, 42)
        Me.DateTimeTglLahir.Name = "DateTimeTglLahir"
        Me.DateTimeTglLahir.Size = New System.Drawing.Size(200, 20)
        Me.DateTimeTglLahir.TabIndex = 100
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(11, 68)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(52, 16)
        Me.Label5.TabIndex = 101
        Me.Label5.Text = "Agama"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(11, 42)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(91, 16)
        Me.Label6.TabIndex = 99
        Me.Label6.Text = "Tanggal Lahir"
        '
        'txttmplhr
        '
        Me.txttmplhr.Location = New System.Drawing.Point(130, 16)
        Me.txttmplhr.Name = "txttmplhr"
        Me.txttmplhr.Size = New System.Drawing.Size(200, 20)
        Me.txttmplhr.TabIndex = 97
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(11, 20)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(87, 16)
        Me.Label7.TabIndex = 96
        Me.Label7.Text = "Tempat Lahir"
        '
        'TabPageDKel1
        '
        Me.TabPageDKel1.BackColor = System.Drawing.SystemColors.Menu
        Me.TabPageDKel1.Controls.Add(Me.GroupBox9)
        Me.TabPageDKel1.Controls.Add(Me.GroupBox10)
        Me.TabPageDKel1.Controls.Add(Me.GroupBox8)
        Me.TabPageDKel1.Controls.Add(Me.GroupBox7)
        Me.TabPageDKel1.Location = New System.Drawing.Point(4, 22)
        Me.TabPageDKel1.Name = "TabPageDKel1"
        Me.TabPageDKel1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPageDKel1.Size = New System.Drawing.Size(762, 388)
        Me.TabPageDKel1.TabIndex = 2
        Me.TabPageDKel1.Text = "Data Suami/Istri"
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.TxtUsiaAnak3)
        Me.GroupBox9.Controls.Add(Me.Label57)
        Me.GroupBox9.Controls.Add(Me.TxtUsiaAnak2)
        Me.GroupBox9.Controls.Add(Me.Label58)
        Me.GroupBox9.Controls.Add(Me.TxtUsiaAnak1)
        Me.GroupBox9.Controls.Add(Me.Label59)
        Me.GroupBox9.Controls.Add(Me.TxtUsiaSuIs)
        Me.GroupBox9.Controls.Add(Me.Label60)
        Me.GroupBox9.Location = New System.Drawing.Point(15, 163)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(338, 196)
        Me.GroupBox9.TabIndex = 115
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "Usia Keluarga"
        '
        'TxtUsiaAnak3
        '
        Me.TxtUsiaAnak3.Location = New System.Drawing.Point(130, 93)
        Me.TxtUsiaAnak3.Name = "TxtUsiaAnak3"
        Me.TxtUsiaAnak3.Size = New System.Drawing.Size(159, 20)
        Me.TxtUsiaAnak3.TabIndex = 108
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label57.ForeColor = System.Drawing.Color.Black
        Me.Label57.Location = New System.Drawing.Point(10, 97)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(80, 16)
        Me.Label57.TabIndex = 107
        Me.Label57.Text = "Usia Anak 3"
        '
        'TxtUsiaAnak2
        '
        Me.TxtUsiaAnak2.Location = New System.Drawing.Point(130, 67)
        Me.TxtUsiaAnak2.Name = "TxtUsiaAnak2"
        Me.TxtUsiaAnak2.Size = New System.Drawing.Size(159, 20)
        Me.TxtUsiaAnak2.TabIndex = 106
        '
        'Label58
        '
        Me.Label58.AutoSize = True
        Me.Label58.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label58.ForeColor = System.Drawing.Color.Black
        Me.Label58.Location = New System.Drawing.Point(10, 72)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(80, 16)
        Me.Label58.TabIndex = 101
        Me.Label58.Text = "Usia Anak 2"
        '
        'TxtUsiaAnak1
        '
        Me.TxtUsiaAnak1.Location = New System.Drawing.Point(130, 41)
        Me.TxtUsiaAnak1.Name = "TxtUsiaAnak1"
        Me.TxtUsiaAnak1.Size = New System.Drawing.Size(159, 20)
        Me.TxtUsiaAnak1.TabIndex = 100
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label59.ForeColor = System.Drawing.Color.Black
        Me.Label59.Location = New System.Drawing.Point(11, 47)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(80, 16)
        Me.Label59.TabIndex = 99
        Me.Label59.Text = "Usia Anak 1"
        '
        'TxtUsiaSuIs
        '
        Me.TxtUsiaSuIs.Location = New System.Drawing.Point(130, 16)
        Me.TxtUsiaSuIs.Name = "TxtUsiaSuIs"
        Me.TxtUsiaSuIs.Size = New System.Drawing.Size(159, 20)
        Me.TxtUsiaSuIs.TabIndex = 97
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label60.ForeColor = System.Drawing.Color.Black
        Me.Label60.Location = New System.Drawing.Point(10, 22)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(101, 16)
        Me.Label60.TabIndex = 96
        Me.Label60.Text = "Usia Istri/Suami"
        '
        'GroupBox10
        '
        Me.GroupBox10.Controls.Add(Me.TxtPekerjaanAnak3)
        Me.GroupBox10.Controls.Add(Me.Label63)
        Me.GroupBox10.Controls.Add(Me.TxtPekerjaanAnak2)
        Me.GroupBox10.Controls.Add(Me.Label64)
        Me.GroupBox10.Controls.Add(Me.TxtPekerjaanAnak1)
        Me.GroupBox10.Controls.Add(Me.Label65)
        Me.GroupBox10.Controls.Add(Me.TxtPkerjaanSuIs)
        Me.GroupBox10.Controls.Add(Me.Label66)
        Me.GroupBox10.Location = New System.Drawing.Point(374, 163)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Size = New System.Drawing.Size(375, 196)
        Me.GroupBox10.TabIndex = 116
        Me.GroupBox10.TabStop = False
        Me.GroupBox10.Text = "Pekerjaan Keluarga"
        '
        'TxtPekerjaanAnak3
        '
        Me.TxtPekerjaanAnak3.Location = New System.Drawing.Point(175, 90)
        Me.TxtPekerjaanAnak3.Name = "TxtPekerjaanAnak3"
        Me.TxtPekerjaanAnak3.Size = New System.Drawing.Size(159, 20)
        Me.TxtPekerjaanAnak3.TabIndex = 108
        '
        'Label63
        '
        Me.Label63.AutoSize = True
        Me.Label63.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label63.ForeColor = System.Drawing.Color.Black
        Me.Label63.Location = New System.Drawing.Point(10, 97)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(114, 16)
        Me.Label63.TabIndex = 107
        Me.Label63.Text = "Pekerjaan Anak 3"
        '
        'TxtPekerjaanAnak2
        '
        Me.TxtPekerjaanAnak2.Location = New System.Drawing.Point(175, 65)
        Me.TxtPekerjaanAnak2.Name = "TxtPekerjaanAnak2"
        Me.TxtPekerjaanAnak2.Size = New System.Drawing.Size(159, 20)
        Me.TxtPekerjaanAnak2.TabIndex = 106
        '
        'Label64
        '
        Me.Label64.AutoSize = True
        Me.Label64.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label64.ForeColor = System.Drawing.Color.Black
        Me.Label64.Location = New System.Drawing.Point(10, 72)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(114, 16)
        Me.Label64.TabIndex = 101
        Me.Label64.Text = "Pekerjaan Anak 2"
        '
        'TxtPekerjaanAnak1
        '
        Me.TxtPekerjaanAnak1.Location = New System.Drawing.Point(175, 41)
        Me.TxtPekerjaanAnak1.Name = "TxtPekerjaanAnak1"
        Me.TxtPekerjaanAnak1.Size = New System.Drawing.Size(159, 20)
        Me.TxtPekerjaanAnak1.TabIndex = 100
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label65.ForeColor = System.Drawing.Color.Black
        Me.Label65.Location = New System.Drawing.Point(11, 47)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(114, 16)
        Me.Label65.TabIndex = 99
        Me.Label65.Text = "Pekerjaan Anak 1"
        '
        'TxtPkerjaanSuIs
        '
        Me.TxtPkerjaanSuIs.Location = New System.Drawing.Point(175, 17)
        Me.TxtPkerjaanSuIs.Name = "TxtPkerjaanSuIs"
        Me.TxtPkerjaanSuIs.Size = New System.Drawing.Size(159, 20)
        Me.TxtPkerjaanSuIs.TabIndex = 97
        '
        'Label66
        '
        Me.Label66.AutoSize = True
        Me.Label66.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label66.ForeColor = System.Drawing.Color.Black
        Me.Label66.Location = New System.Drawing.Point(10, 22)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(135, 16)
        Me.Label66.TabIndex = 96
        Me.Label66.Text = "Pekerjaan Istri/Suami"
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.TxtPendidikanAnak3)
        Me.GroupBox8.Controls.Add(Me.Label51)
        Me.GroupBox8.Controls.Add(Me.TxtPendidikanAnak2)
        Me.GroupBox8.Controls.Add(Me.Label53)
        Me.GroupBox8.Controls.Add(Me.TxtPendidikanAnak1)
        Me.GroupBox8.Controls.Add(Me.Label54)
        Me.GroupBox8.Controls.Add(Me.TxtPendidikanSuIs)
        Me.GroupBox8.Controls.Add(Me.Label56)
        Me.GroupBox8.Location = New System.Drawing.Point(369, 15)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(380, 131)
        Me.GroupBox8.TabIndex = 114
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "Pendidikan Keluarga"
        '
        'TxtPendidikanAnak3
        '
        Me.TxtPendidikanAnak3.Location = New System.Drawing.Point(175, 97)
        Me.TxtPendidikanAnak3.Name = "TxtPendidikanAnak3"
        Me.TxtPendidikanAnak3.Size = New System.Drawing.Size(159, 20)
        Me.TxtPendidikanAnak3.TabIndex = 110
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label51.ForeColor = System.Drawing.Color.Black
        Me.Label51.Location = New System.Drawing.Point(10, 101)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(120, 16)
        Me.Label51.TabIndex = 109
        Me.Label51.Text = "Pendidikan Anak 3"
        '
        'TxtPendidikanAnak2
        '
        Me.TxtPendidikanAnak2.Location = New System.Drawing.Point(175, 73)
        Me.TxtPendidikanAnak2.Name = "TxtPendidikanAnak2"
        Me.TxtPendidikanAnak2.Size = New System.Drawing.Size(159, 20)
        Me.TxtPendidikanAnak2.TabIndex = 108
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label53.ForeColor = System.Drawing.Color.Black
        Me.Label53.Location = New System.Drawing.Point(10, 74)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(120, 16)
        Me.Label53.TabIndex = 107
        Me.Label53.Text = "Pendidikan Anak 2"
        '
        'TxtPendidikanAnak1
        '
        Me.TxtPendidikanAnak1.Location = New System.Drawing.Point(175, 44)
        Me.TxtPendidikanAnak1.Name = "TxtPendidikanAnak1"
        Me.TxtPendidikanAnak1.Size = New System.Drawing.Size(159, 20)
        Me.TxtPendidikanAnak1.TabIndex = 106
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label54.ForeColor = System.Drawing.Color.Black
        Me.Label54.Location = New System.Drawing.Point(10, 48)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(120, 16)
        Me.Label54.TabIndex = 101
        Me.Label54.Text = "Pendidikan Anak 1"
        '
        'TxtPendidikanSuIs
        '
        Me.TxtPendidikanSuIs.Location = New System.Drawing.Point(175, 17)
        Me.TxtPendidikanSuIs.Name = "TxtPendidikanSuIs"
        Me.TxtPendidikanSuIs.Size = New System.Drawing.Size(159, 20)
        Me.TxtPendidikanSuIs.TabIndex = 97
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label56.ForeColor = System.Drawing.Color.Black
        Me.Label56.Location = New System.Drawing.Point(10, 22)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(141, 16)
        Me.Label56.TabIndex = 96
        Me.Label56.Text = "Pendidikan Istri/Suami"
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.TxtNamaAnak3)
        Me.GroupBox7.Controls.Add(Me.Label48)
        Me.GroupBox7.Controls.Add(Me.TxtNamaAnak2)
        Me.GroupBox7.Controls.Add(Me.Label49)
        Me.GroupBox7.Controls.Add(Me.TxtNamaAnak1)
        Me.GroupBox7.Controls.Add(Me.Label50)
        Me.GroupBox7.Controls.Add(Me.txtNamaSuIs)
        Me.GroupBox7.Controls.Add(Me.Label52)
        Me.GroupBox7.Location = New System.Drawing.Point(15, 15)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(338, 131)
        Me.GroupBox7.TabIndex = 2
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Data Keluarga"
        '
        'TxtNamaAnak3
        '
        Me.TxtNamaAnak3.Location = New System.Drawing.Point(130, 96)
        Me.TxtNamaAnak3.Name = "TxtNamaAnak3"
        Me.TxtNamaAnak3.Size = New System.Drawing.Size(159, 20)
        Me.TxtNamaAnak3.TabIndex = 110
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label48.ForeColor = System.Drawing.Color.Black
        Me.Label48.Location = New System.Drawing.Point(6, 101)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(89, 16)
        Me.Label48.TabIndex = 109
        Me.Label48.Text = "Nama Anak 3"
        '
        'TxtNamaAnak2
        '
        Me.TxtNamaAnak2.Location = New System.Drawing.Point(130, 68)
        Me.TxtNamaAnak2.Name = "TxtNamaAnak2"
        Me.TxtNamaAnak2.Size = New System.Drawing.Size(159, 20)
        Me.TxtNamaAnak2.TabIndex = 108
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label49.ForeColor = System.Drawing.Color.Black
        Me.Label49.Location = New System.Drawing.Point(6, 74)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(89, 16)
        Me.Label49.TabIndex = 107
        Me.Label49.Text = "Nama Anak 2"
        '
        'TxtNamaAnak1
        '
        Me.TxtNamaAnak1.Location = New System.Drawing.Point(130, 42)
        Me.TxtNamaAnak1.Name = "TxtNamaAnak1"
        Me.TxtNamaAnak1.Size = New System.Drawing.Size(159, 20)
        Me.TxtNamaAnak1.TabIndex = 106
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label50.ForeColor = System.Drawing.Color.Black
        Me.Label50.Location = New System.Drawing.Point(6, 48)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(89, 16)
        Me.Label50.TabIndex = 101
        Me.Label50.Text = "Nama Anak 1"
        '
        'txtNamaSuIs
        '
        Me.txtNamaSuIs.Location = New System.Drawing.Point(130, 16)
        Me.txtNamaSuIs.Name = "txtNamaSuIs"
        Me.txtNamaSuIs.Size = New System.Drawing.Size(159, 20)
        Me.txtNamaSuIs.TabIndex = 97
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label52.ForeColor = System.Drawing.Color.Black
        Me.Label52.Location = New System.Drawing.Point(6, 21)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(110, 16)
        Me.Label52.TabIndex = 96
        Me.Label52.Text = "Nama Istri/Suami"
        '
        'TabPageDkel2
        '
        Me.TabPageDkel2.BackColor = System.Drawing.SystemColors.Menu
        Me.TabPageDkel2.Controls.Add(Me.GroupBox6)
        Me.TabPageDkel2.Controls.Add(Me.GroupBox5)
        Me.TabPageDkel2.Controls.Add(Me.GroupBox4)
        Me.TabPageDkel2.Controls.Add(Me.GroupBox3)
        Me.TabPageDkel2.Location = New System.Drawing.Point(4, 22)
        Me.TabPageDkel2.Name = "TabPageDkel2"
        Me.TabPageDkel2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPageDkel2.Size = New System.Drawing.Size(762, 388)
        Me.TabPageDkel2.TabIndex = 1
        Me.TabPageDkel2.Text = "Data Keluarga"
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.txtUsiaSdr3)
        Me.GroupBox6.Controls.Add(Me.Label42)
        Me.GroupBox6.Controls.Add(Me.txtUsiaSdr2)
        Me.GroupBox6.Controls.Add(Me.Label43)
        Me.GroupBox6.Controls.Add(Me.txtUsiaSdr1)
        Me.GroupBox6.Controls.Add(Me.Label44)
        Me.GroupBox6.Controls.Add(Me.txtUsiaIbu)
        Me.GroupBox6.Controls.Add(Me.Label45)
        Me.GroupBox6.Controls.Add(Me.txtUsiaAyah)
        Me.GroupBox6.Controls.Add(Me.Label46)
        Me.GroupBox6.Location = New System.Drawing.Point(15, 192)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(338, 177)
        Me.GroupBox6.TabIndex = 113
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Usia Keluarga"
        '
        'txtUsiaSdr3
        '
        Me.txtUsiaSdr3.Location = New System.Drawing.Point(130, 133)
        Me.txtUsiaSdr3.Name = "txtUsiaSdr3"
        Me.txtUsiaSdr3.Size = New System.Drawing.Size(159, 20)
        Me.txtUsiaSdr3.TabIndex = 110
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.ForeColor = System.Drawing.Color.Black
        Me.Label42.Location = New System.Drawing.Point(10, 135)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(101, 16)
        Me.Label42.TabIndex = 109
        Me.Label42.Text = "Usia Saudara 3"
        '
        'txtUsiaSdr2
        '
        Me.txtUsiaSdr2.Location = New System.Drawing.Point(130, 107)
        Me.txtUsiaSdr2.Name = "txtUsiaSdr2"
        Me.txtUsiaSdr2.Size = New System.Drawing.Size(159, 20)
        Me.txtUsiaSdr2.TabIndex = 108
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label43.ForeColor = System.Drawing.Color.Black
        Me.Label43.Location = New System.Drawing.Point(10, 111)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(101, 16)
        Me.Label43.TabIndex = 107
        Me.Label43.Text = "Usia Saudara 2"
        '
        'txtUsiaSdr1
        '
        Me.txtUsiaSdr1.Location = New System.Drawing.Point(130, 81)
        Me.txtUsiaSdr1.Name = "txtUsiaSdr1"
        Me.txtUsiaSdr1.Size = New System.Drawing.Size(159, 20)
        Me.txtUsiaSdr1.TabIndex = 106
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label44.ForeColor = System.Drawing.Color.Black
        Me.Label44.Location = New System.Drawing.Point(10, 86)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(101, 16)
        Me.Label44.TabIndex = 101
        Me.Label44.Text = "Usia Saudara 1"
        '
        'txtUsiaIbu
        '
        Me.txtUsiaIbu.Location = New System.Drawing.Point(130, 55)
        Me.txtUsiaIbu.Name = "txtUsiaIbu"
        Me.txtUsiaIbu.Size = New System.Drawing.Size(159, 20)
        Me.txtUsiaIbu.TabIndex = 100
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label45.ForeColor = System.Drawing.Color.Black
        Me.Label45.Location = New System.Drawing.Point(11, 61)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(57, 16)
        Me.Label45.TabIndex = 99
        Me.Label45.Text = "Usia Ibu"
        '
        'txtUsiaAyah
        '
        Me.txtUsiaAyah.Location = New System.Drawing.Point(130, 30)
        Me.txtUsiaAyah.Name = "txtUsiaAyah"
        Me.txtUsiaAyah.Size = New System.Drawing.Size(159, 20)
        Me.txtUsiaAyah.TabIndex = 97
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label46.ForeColor = System.Drawing.Color.Black
        Me.Label46.Location = New System.Drawing.Point(10, 36)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(67, 16)
        Me.Label46.TabIndex = 96
        Me.Label46.Text = "UsiaAyah"
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.txtPekerjaanSdr3)
        Me.GroupBox5.Controls.Add(Me.Label36)
        Me.GroupBox5.Controls.Add(Me.txtPekerjaanSdr2)
        Me.GroupBox5.Controls.Add(Me.Label37)
        Me.GroupBox5.Controls.Add(Me.txtPekerjaanSdr1)
        Me.GroupBox5.Controls.Add(Me.Label38)
        Me.GroupBox5.Controls.Add(Me.txtPekerjaanIbu)
        Me.GroupBox5.Controls.Add(Me.Label39)
        Me.GroupBox5.Controls.Add(Me.txtPekerjaanAyah)
        Me.GroupBox5.Controls.Add(Me.Label40)
        Me.GroupBox5.Location = New System.Drawing.Point(374, 192)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(364, 177)
        Me.GroupBox5.TabIndex = 114
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Pekerjaan Keluarga"
        '
        'txtPekerjaanSdr3
        '
        Me.txtPekerjaanSdr3.Location = New System.Drawing.Point(180, 129)
        Me.txtPekerjaanSdr3.Name = "txtPekerjaanSdr3"
        Me.txtPekerjaanSdr3.Size = New System.Drawing.Size(159, 20)
        Me.txtPekerjaanSdr3.TabIndex = 110
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.ForeColor = System.Drawing.Color.Black
        Me.Label36.Location = New System.Drawing.Point(15, 135)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(135, 16)
        Me.Label36.TabIndex = 109
        Me.Label36.Text = "Pekerjaan Saudara 3"
        '
        'txtPekerjaanSdr2
        '
        Me.txtPekerjaanSdr2.Location = New System.Drawing.Point(180, 104)
        Me.txtPekerjaanSdr2.Name = "txtPekerjaanSdr2"
        Me.txtPekerjaanSdr2.Size = New System.Drawing.Size(159, 20)
        Me.txtPekerjaanSdr2.TabIndex = 108
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.ForeColor = System.Drawing.Color.Black
        Me.Label37.Location = New System.Drawing.Point(15, 111)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(135, 16)
        Me.Label37.TabIndex = 107
        Me.Label37.Text = "Pekerjaan Saudara 2"
        '
        'txtPekerjaanSdr1
        '
        Me.txtPekerjaanSdr1.Location = New System.Drawing.Point(180, 79)
        Me.txtPekerjaanSdr1.Name = "txtPekerjaanSdr1"
        Me.txtPekerjaanSdr1.Size = New System.Drawing.Size(159, 20)
        Me.txtPekerjaanSdr1.TabIndex = 106
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.ForeColor = System.Drawing.Color.Black
        Me.Label38.Location = New System.Drawing.Point(15, 86)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(135, 16)
        Me.Label38.TabIndex = 101
        Me.Label38.Text = "Pekerjaan Saudara 1"
        '
        'txtPekerjaanIbu
        '
        Me.txtPekerjaanIbu.Location = New System.Drawing.Point(180, 55)
        Me.txtPekerjaanIbu.Name = "txtPekerjaanIbu"
        Me.txtPekerjaanIbu.Size = New System.Drawing.Size(159, 20)
        Me.txtPekerjaanIbu.TabIndex = 100
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.ForeColor = System.Drawing.Color.Black
        Me.Label39.Location = New System.Drawing.Point(16, 61)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(91, 16)
        Me.Label39.TabIndex = 99
        Me.Label39.Text = "Pekerjaan Ibu"
        '
        'txtPekerjaanAyah
        '
        Me.txtPekerjaanAyah.Location = New System.Drawing.Point(180, 31)
        Me.txtPekerjaanAyah.Name = "txtPekerjaanAyah"
        Me.txtPekerjaanAyah.Size = New System.Drawing.Size(159, 20)
        Me.txtPekerjaanAyah.TabIndex = 97
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.ForeColor = System.Drawing.Color.Black
        Me.Label40.Location = New System.Drawing.Point(15, 36)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(104, 16)
        Me.Label40.TabIndex = 96
        Me.Label40.Text = "Pekerjaan Ayah"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.txtPendidikanSdr3)
        Me.GroupBox4.Controls.Add(Me.Label24)
        Me.GroupBox4.Controls.Add(Me.txtPendidikanSdr2)
        Me.GroupBox4.Controls.Add(Me.Label25)
        Me.GroupBox4.Controls.Add(Me.txtPendidikanSdr1)
        Me.GroupBox4.Controls.Add(Me.Label26)
        Me.GroupBox4.Controls.Add(Me.txtPendidikanIbu)
        Me.GroupBox4.Controls.Add(Me.Label33)
        Me.GroupBox4.Controls.Add(Me.txtPendidikanAyah)
        Me.GroupBox4.Controls.Add(Me.Label34)
        Me.GroupBox4.Location = New System.Drawing.Point(374, 6)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(364, 177)
        Me.GroupBox4.TabIndex = 113
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Pendidikan Keluarga"
        '
        'txtPendidikanSdr3
        '
        Me.txtPendidikanSdr3.Location = New System.Drawing.Point(181, 127)
        Me.txtPendidikanSdr3.Name = "txtPendidikanSdr3"
        Me.txtPendidikanSdr3.Size = New System.Drawing.Size(159, 20)
        Me.txtPendidikanSdr3.TabIndex = 110
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.ForeColor = System.Drawing.Color.Black
        Me.Label24.Location = New System.Drawing.Point(16, 133)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(141, 16)
        Me.Label24.TabIndex = 109
        Me.Label24.Text = "Pendidikan Saudara 3"
        '
        'txtPendidikanSdr2
        '
        Me.txtPendidikanSdr2.Location = New System.Drawing.Point(181, 102)
        Me.txtPendidikanSdr2.Name = "txtPendidikanSdr2"
        Me.txtPendidikanSdr2.Size = New System.Drawing.Size(159, 20)
        Me.txtPendidikanSdr2.TabIndex = 108
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.ForeColor = System.Drawing.Color.Black
        Me.Label25.Location = New System.Drawing.Point(16, 109)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(141, 16)
        Me.Label25.TabIndex = 107
        Me.Label25.Text = "Pendidikan Saudara 2"
        '
        'txtPendidikanSdr1
        '
        Me.txtPendidikanSdr1.Location = New System.Drawing.Point(181, 77)
        Me.txtPendidikanSdr1.Name = "txtPendidikanSdr1"
        Me.txtPendidikanSdr1.Size = New System.Drawing.Size(159, 20)
        Me.txtPendidikanSdr1.TabIndex = 106
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.ForeColor = System.Drawing.Color.Black
        Me.Label26.Location = New System.Drawing.Point(16, 84)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(141, 16)
        Me.Label26.TabIndex = 101
        Me.Label26.Text = "Pendidikan Saudara 1"
        '
        'txtPendidikanIbu
        '
        Me.txtPendidikanIbu.Location = New System.Drawing.Point(181, 53)
        Me.txtPendidikanIbu.Name = "txtPendidikanIbu"
        Me.txtPendidikanIbu.Size = New System.Drawing.Size(159, 20)
        Me.txtPendidikanIbu.TabIndex = 100
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.ForeColor = System.Drawing.Color.Black
        Me.Label33.Location = New System.Drawing.Point(17, 59)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(97, 16)
        Me.Label33.TabIndex = 99
        Me.Label33.Text = "Pendidikan Ibu"
        '
        'txtPendidikanAyah
        '
        Me.txtPendidikanAyah.Location = New System.Drawing.Point(181, 29)
        Me.txtPendidikanAyah.Name = "txtPendidikanAyah"
        Me.txtPendidikanAyah.Size = New System.Drawing.Size(159, 20)
        Me.txtPendidikanAyah.TabIndex = 97
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.ForeColor = System.Drawing.Color.Black
        Me.Label34.Location = New System.Drawing.Point(16, 34)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(110, 16)
        Me.Label34.TabIndex = 96
        Me.Label34.Text = "Pendidikan Ayah"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.txtNamaSdr3)
        Me.GroupBox3.Controls.Add(Me.Label28)
        Me.GroupBox3.Controls.Add(Me.txtNamaSdr2)
        Me.GroupBox3.Controls.Add(Me.Label29)
        Me.GroupBox3.Controls.Add(Me.txtNamaSdr1)
        Me.GroupBox3.Controls.Add(Me.Label30)
        Me.GroupBox3.Controls.Add(Me.TxtNamaIbu)
        Me.GroupBox3.Controls.Add(Me.Label31)
        Me.GroupBox3.Controls.Add(Me.txtNamaAyah)
        Me.GroupBox3.Controls.Add(Me.Label32)
        Me.GroupBox3.Location = New System.Drawing.Point(15, 6)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(338, 177)
        Me.GroupBox3.TabIndex = 1
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Data Keluarga"
        '
        'txtNamaSdr3
        '
        Me.txtNamaSdr3.Location = New System.Drawing.Point(130, 129)
        Me.txtNamaSdr3.Name = "txtNamaSdr3"
        Me.txtNamaSdr3.Size = New System.Drawing.Size(159, 20)
        Me.txtNamaSdr3.TabIndex = 110
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.ForeColor = System.Drawing.Color.Black
        Me.Label28.Location = New System.Drawing.Point(10, 131)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(110, 16)
        Me.Label28.TabIndex = 109
        Me.Label28.Text = "Nama Saudara 3"
        '
        'txtNamaSdr2
        '
        Me.txtNamaSdr2.Location = New System.Drawing.Point(130, 103)
        Me.txtNamaSdr2.Name = "txtNamaSdr2"
        Me.txtNamaSdr2.Size = New System.Drawing.Size(159, 20)
        Me.txtNamaSdr2.TabIndex = 108
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.ForeColor = System.Drawing.Color.Black
        Me.Label29.Location = New System.Drawing.Point(10, 107)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(110, 16)
        Me.Label29.TabIndex = 107
        Me.Label29.Text = "Nama Saudara 2"
        '
        'txtNamaSdr1
        '
        Me.txtNamaSdr1.Location = New System.Drawing.Point(130, 77)
        Me.txtNamaSdr1.Name = "txtNamaSdr1"
        Me.txtNamaSdr1.Size = New System.Drawing.Size(159, 20)
        Me.txtNamaSdr1.TabIndex = 106
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.ForeColor = System.Drawing.Color.Black
        Me.Label30.Location = New System.Drawing.Point(10, 82)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(110, 16)
        Me.Label30.TabIndex = 101
        Me.Label30.Text = "Nama Saudara 1"
        '
        'TxtNamaIbu
        '
        Me.TxtNamaIbu.Location = New System.Drawing.Point(130, 51)
        Me.TxtNamaIbu.Name = "TxtNamaIbu"
        Me.TxtNamaIbu.Size = New System.Drawing.Size(159, 20)
        Me.TxtNamaIbu.TabIndex = 100
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.ForeColor = System.Drawing.Color.Black
        Me.Label31.Location = New System.Drawing.Point(11, 57)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(66, 16)
        Me.Label31.TabIndex = 99
        Me.Label31.Text = "Nama Ibu"
        '
        'txtNamaAyah
        '
        Me.txtNamaAyah.Location = New System.Drawing.Point(130, 26)
        Me.txtNamaAyah.Name = "txtNamaAyah"
        Me.txtNamaAyah.Size = New System.Drawing.Size(159, 20)
        Me.txtNamaAyah.TabIndex = 97
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.ForeColor = System.Drawing.Color.Black
        Me.Label32.Location = New System.Drawing.Point(10, 32)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(79, 16)
        Me.Label32.TabIndex = 96
        Me.Label32.Text = "Nama Ayah"
        '
        'KandidatForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Menu
        Me.ClientSize = New System.Drawing.Size(1052, 481)
        Me.Controls.Add(Me.TabControl1)
        Me.ForeColor = System.Drawing.Color.Black
        Me.Name = "KandidatForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "KandidatForm"
        Me.TabControl1.ResumeLayout(false)
        Me.TabPageDdiri.ResumeLayout(false)
        Me.TabPageDdiri.PerformLayout
        Me.GroupBox2.ResumeLayout(false)
        Me.GroupBox2.PerformLayout
        Me.GroupBox1.ResumeLayout(false)
        Me.GroupBox1.PerformLayout
        Me.TabPageDKel1.ResumeLayout(false)
        Me.GroupBox9.ResumeLayout(false)
        Me.GroupBox9.PerformLayout
        Me.GroupBox10.ResumeLayout(false)
        Me.GroupBox10.PerformLayout
        Me.GroupBox8.ResumeLayout(false)
        Me.GroupBox8.PerformLayout
        Me.GroupBox7.ResumeLayout(false)
        Me.GroupBox7.PerformLayout
        Me.TabPageDkel2.ResumeLayout(false)
        Me.GroupBox6.ResumeLayout(false)
        Me.GroupBox6.PerformLayout
        Me.GroupBox5.ResumeLayout(false)
        Me.GroupBox5.PerformLayout
        Me.GroupBox4.ResumeLayout(false)
        Me.GroupBox4.PerformLayout
        Me.GroupBox3.ResumeLayout(false)
        Me.GroupBox3.PerformLayout
        Me.ResumeLayout(false)

End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPageDdiri As System.Windows.Forms.TabPage
    Friend WithEvents TabPageDkel2 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents ComboStatuskand As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TxtNama As System.Windows.Forms.TextBox
    Friend WithEvents TxtKode As System.Windows.Forms.TextBox
    Friend WithEvents DateTimePickerJoin As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents DateTimeTglLahir As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txttmplhr As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents txtnotlp As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txtalamat As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtnoktp As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents txtpendidikan As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents txtareaPenemp As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents txtnonpwp As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents txtnobpjs As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Btnbatal As System.Windows.Forms.Button
    Friend WithEvents btnsimpan As System.Windows.Forms.Button
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents txtnorek As System.Windows.Forms.TextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents txtUsiaSdr3 As System.Windows.Forms.TextBox
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents txtUsiaSdr2 As System.Windows.Forms.TextBox
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents txtUsiaSdr1 As System.Windows.Forms.TextBox
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents txtUsiaIbu As System.Windows.Forms.TextBox
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents txtUsiaAyah As System.Windows.Forms.TextBox
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents txtPekerjaanSdr3 As System.Windows.Forms.TextBox
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents txtPekerjaanSdr2 As System.Windows.Forms.TextBox
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents txtPekerjaanSdr1 As System.Windows.Forms.TextBox
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents txtPekerjaanIbu As System.Windows.Forms.TextBox
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents txtPekerjaanAyah As System.Windows.Forms.TextBox
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents txtPendidikanSdr3 As System.Windows.Forms.TextBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents txtPendidikanSdr2 As System.Windows.Forms.TextBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents txtPendidikanSdr1 As System.Windows.Forms.TextBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents txtPendidikanIbu As System.Windows.Forms.TextBox
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents txtPendidikanAyah As System.Windows.Forms.TextBox
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents txtNamaSdr3 As System.Windows.Forms.TextBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents txtNamaSdr2 As System.Windows.Forms.TextBox
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents txtNamaSdr1 As System.Windows.Forms.TextBox
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents TxtNamaIbu As System.Windows.Forms.TextBox
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents txtNamaAyah As System.Windows.Forms.TextBox
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents TabPageDKel1 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox9 As System.Windows.Forms.GroupBox
    Friend WithEvents TxtUsiaAnak3 As System.Windows.Forms.TextBox
    Friend WithEvents Label57 As System.Windows.Forms.Label
    Friend WithEvents TxtUsiaAnak2 As System.Windows.Forms.TextBox
    Friend WithEvents Label58 As System.Windows.Forms.Label
    Friend WithEvents TxtUsiaAnak1 As System.Windows.Forms.TextBox
    Friend WithEvents Label59 As System.Windows.Forms.Label
    Friend WithEvents TxtUsiaSuIs As System.Windows.Forms.TextBox
    Friend WithEvents Label60 As System.Windows.Forms.Label
    Friend WithEvents GroupBox10 As System.Windows.Forms.GroupBox
    Friend WithEvents TxtPekerjaanAnak3 As System.Windows.Forms.TextBox
    Friend WithEvents Label63 As System.Windows.Forms.Label
    Friend WithEvents TxtPekerjaanAnak2 As System.Windows.Forms.TextBox
    Friend WithEvents Label64 As System.Windows.Forms.Label
    Friend WithEvents TxtPekerjaanAnak1 As System.Windows.Forms.TextBox
    Friend WithEvents Label65 As System.Windows.Forms.Label
    Friend WithEvents TxtPkerjaanSuIs As System.Windows.Forms.TextBox
    Friend WithEvents Label66 As System.Windows.Forms.Label
    Friend WithEvents GroupBox8 As System.Windows.Forms.GroupBox
    Friend WithEvents TxtPendidikanAnak3 As System.Windows.Forms.TextBox
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents TxtPendidikanAnak2 As System.Windows.Forms.TextBox
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents TxtPendidikanAnak1 As System.Windows.Forms.TextBox
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents TxtPendidikanSuIs As System.Windows.Forms.TextBox
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents TxtNamaAnak3 As System.Windows.Forms.TextBox
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents TxtNamaAnak2 As System.Windows.Forms.TextBox
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents TxtNamaAnak1 As System.Windows.Forms.TextBox
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents txtNamaSuIs As System.Windows.Forms.TextBox
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents ComboKdJabatan As System.Windows.Forms.ComboBox
    Friend WithEvents ComboKdDivisi As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBoxAgama As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBoxKawin As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBoxJenisKl As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBoxTenagaKerja As System.Windows.Forms.ComboBox
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents txtMasaBerlakuktp As System.Windows.Forms.TextBox
End Class
