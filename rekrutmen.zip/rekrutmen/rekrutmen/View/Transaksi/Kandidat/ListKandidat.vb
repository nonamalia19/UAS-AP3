﻿Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports System.IO
Public Class ListKandidat
    Dim ctrl As New CtrlKandidat
    Dim ctrlHis As New CtrlHisKeluarga
    Dim ctrlHisHub As New CtrlHisHubKeluarga
    Dim mdlkndt As New ModelKandidat

    Private Sub ListCustomer_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ctrl.tampilkanData(DGV)
    End Sub

    Private Sub txtCari_TextChanged(sender As Object, e As EventArgs) Handles txtCari.TextChanged
        ctrl.cariData(txtCari)
    End Sub
    Private Sub DGV_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DGV.CellClick
        If DGV.Rows.Count > 0 Then
            id_kandidat = DGV.CurrentRow.Cells(0).Value.ToString
        End If
    End Sub

    Private Sub AddToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AddToolStripMenuItem.Click
        FlagSimpanUpdate = "Add"
        KandidatForm.Show()
    End Sub

    Private Sub UpdateToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles UpdateToolStripMenuItem.Click
        If (id_kandidat.Trim() = "") Then
            MessageBox.Show("Silahkan pilih salah satu data yang ingin di update")
        Else
            FlagSimpanUpdate = "Update"
            KandidatForm.Show()
        End If

    End Sub

    Private Sub RefreshToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RefreshToolStripMenuItem.Click
        ctrl.tampilkanData(DGV)
    End Sub

    Private Sub DeleteToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DeleteToolStripMenuItem.Click
        Dim hasil As DialogResult = MessageBox.Show("Apakah Anda Yakin Akan Mengapus Data " + id_kandidat + "?",
                                                    "Konfirmasi",
                                                    MessageBoxButtons.YesNo)
        If hasil = DialogResult.Yes Then
            ctrl.HapusData(id_kandidat)
            ctrlHis.HapusData(id_kandidat)
            ctrlHisHub.HapusData(id_kandidat)

        End If
    End Sub

    Private Sub PrintLayoutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PrintLayoutToolStripMenuItem.Click
        Dim cryRpt As New ReportDocument
        Dim formr As New Report
        Dim docPath As String = Path.Combine(My.Application.Info.DirectoryPath, "Report\")
        cryRpt.Load(docPath + "LayoutKandidat.rpt")
        cryRpt.SetDataSource(mdlkndt.TabelLayout(id_kandidat))
        formr.CrystalReportViewer1.ReportSource = cryRpt
        formr.Show()
    End Sub
    Private Sub Btnprint_Click(sender As Object, e As EventArgs) Handles Btnprint.Click
        Dim cryRpt As New ReportDocument
        Dim formr As New Report
        Dim docPath As String = Path.Combine(My.Application.Info.DirectoryPath, "Report\")
        cryRpt.Load(docPath + "ReportKandidat.rpt")
        cryRpt.SetDataSource(mdlkndt.TabelReportkand(DateTimePicker1.Value.ToString("yyyy-MM-dd")))
        formr.CrystalReportViewer1.ReportSource = cryRpt
        formr.Show()
    End Sub

End Class