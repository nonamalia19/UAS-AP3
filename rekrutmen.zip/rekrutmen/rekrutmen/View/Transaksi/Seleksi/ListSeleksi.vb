﻿Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports System.IO

Public Class ListSeleksi


    Dim ctrl As New CtrlSeleksi
    Dim mdlSelesksi As New Modelseleksi

    Private Sub ListCustomer_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ctrl.tampilkandt(DGV)
    End Sub

    Private Sub txtCari_TextChanged(sender As Object, e As EventArgs) Handles txtCari.TextChanged
        ctrl.Caridt(txtCari)
    End Sub
    Private Sub DGV_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DGV.CellClick
        If DGV.Rows.Count > 0 Then
            id_kandidat = DGV.CurrentRow.Cells(0).Value.ToString
        End If
    End Sub

    Private Sub AddToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TambahToolStripMenuItem.Click
        FlagSimpanUpdate = "Add"
        Seleksi.Show()
    End Sub

    Private Sub UpdateToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles UpdateToolStripMenuItem.Click
        If (id_kandidat.Trim() = "") Then
            MessageBox.Show("Silahkan pilih salah satu data yang ingin di update")
        Else
            FlagSimpanUpdate = "Update"
            Seleksi.Show()
        End If
        
    End Sub

    Private Sub RefreshToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RefreshToolStripMenuItem.Click
        ctrl.tampilkandt(DGV)
    End Sub

    Private Sub DeleteToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HapusToolStripMenuItem.Click
        Dim hasil As DialogResult = MessageBox.Show("Apakah Anda Yakin Akan Mengapus Data " + id_kandidat + "?",
                                                    "Konfirmasi",
                                                    MessageBoxButtons.YesNo)
        If hasil = DialogResult.Yes Then
            ctrl.hapusdata(id_kandidat)

        End If
    End Sub


    Private Sub PrintLayoutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PrintLayoutToolStripMenuItem.Click
        Dim cryRpt As New ReportDocument
        Dim formr As New Report
        Dim docPath As String = Path.Combine(My.Application.Info.DirectoryPath, "Report\")
        cryRpt.Load(docPath + "LayoutSelelksi.rpt")
        cryRpt.SetDataSource(mdlSelesksi.TabelLayoutSeleksi(id_kandidat))
        formr.CrystalReportViewer1.ReportSource = cryRpt
        formr.Show()
    End Sub
End Class