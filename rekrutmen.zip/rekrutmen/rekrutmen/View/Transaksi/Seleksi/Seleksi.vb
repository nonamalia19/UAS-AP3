﻿Public Class Seleksi
    Dim result As Boolean
    Dim slk As New EntSeleksi
    Dim ctrlslk As New CtrlSeleksi

    Private Sub SetTampilkanDataUpdate()
        Try

            ComboBoxIDKand.Items.Add(slk.id_kdt.Trim())
            ComboBoxIDKand.Text = slk.id_kdt.Trim()
            ComboBoxIDKand.Enabled = False
            TxtNama.Text = slk.nm_kdt.Trim()
            TextBoxJabatan.Text = slk.jbt.Trim()
            TextBoxDivisi.Text = slk.div.Trim()
            TextBoxPendidikan.Text = slk.pend.Trim()
            TextBoxTenagaKerja.Text = slk.tg_kerja.Trim()
            ComboBoxTestA.Text = slk.N_TestA.Trim()
            ComboBoxTestKrap.Text = slk.N_TestKraeplin.Trim()
            ComboBoxTestArit.Text = slk.N_TestAritmatika.Trim()
            ComboBoxTestKeprib.Text = slk.N_TestKpribadian.Trim()
            txtidus.Text = slk.id_use.Trim()

        Catch ex As Exception
            MessageBox.Show(ex.ToString())
            Return
        End Try

    End Sub

    Private Sub setslk()
        slk.id_kdt = ComboBoxIDKand.Text
        slk.nm_kdt = TxtNama.Text
        slk.jbt = TextBoxJabatan.Text
        slk.div = TextBoxDivisi.Text
        slk.pend = TextBoxPendidikan.Text
        slk.tg_kerja = TextBoxTenagaKerja.Text
        slk.N_TestA = ComboBoxTestA.Text
        slk.N_TestKraeplin = ComboBoxTestKrap.Text
        slk.N_TestAritmatika = ComboBoxTestArit.Text
        slk.N_TestKpribadian = ComboBoxTestKeprib.Text
        slk.id_use = txtidus.Text
    End Sub

    Private Sub resetslk()
        slk.id_kdt = ""
        slk.nm_kdt = ""
        slk.jbt = ""
        slk.div = ""
        slk.pend = ""
        slk.tg_kerja = ""
        slk.N_TestA = ""
        slk.N_TestKraeplin = ""
        slk.N_TestAritmatika = ""
        slk.N_TestKpribadian = ""
        slk.id_use = ""
    End Sub

    Private Sub simpan_Click(sender As Object, e As EventArgs) Handles btnsimpan.Click

        'resetslk()
        setslk()
        If FlagSimpanUpdate.ToUpper().Trim() = "ADD" Then
            If (ctrlslk.td(slk)) Then
                result = True
            End If
        ElseIf FlagSimpanUpdate.ToUpper().Trim() = "UPDATE" Then
            setslk()
            If (ctrlslk.editdata(slk)) Then
                result = True
            End If
        End If

        If result = True Then
            Me.Dispose()
            ListSeleksi.Focus()
        End If


    End Sub

    Private Sub Seleksi_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtidus.Text = id_user
        If (FlagSimpanUpdate.ToUpper.Trim() = "ADD") Then
            ctrlslk.SetComboIDKandidat(ComboBoxIDKand)
        ElseIf (FlagSimpanUpdate.ToUpper().Trim() = "UPDATE") Then
            slk = ctrlslk.cariDtByKode(id_kandidat)
            SetTampilkanDataUpdate()
        End If
    End Sub
    Dim model As New Modelseleksi

    Private Sub WhenIDCandidatSelect(ByVal id As String)
        Dim tabel As DataTable = model.TabelWhenIDSelected(id)
        TxtNama.Text = tabel.Rows(0)(1).ToString()
        TextBoxJabatan.Text = tabel.Rows(0)(17).ToString()
        TextBoxDivisi.Text = tabel.Rows(0)(18).ToString()
        TextBoxPendidikan.Text = tabel.Rows(0)(5).ToString()
        TextBoxTenagaKerja.Text = tabel.Rows(0)(15).ToString()

    End Sub

    Private Sub ComboBoxIDKand_SelectedIndexChanged(sender As Object, e As EventArgs)
        If (FlagSimpanUpdate.ToUpper().Trim() = "ADD") Then
            id_kandidat = ComboBoxIDKand.Text
            WhenIDCandidatSelect(id_kandidat)
        End If
    End Sub
End Class