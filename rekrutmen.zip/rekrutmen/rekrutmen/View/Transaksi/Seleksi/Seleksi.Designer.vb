﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Seleksi
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Seleksi))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TxtNama = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.ComboBoxTestKeprib = New System.Windows.Forms.ComboBox()
        Me.ComboBoxTestArit = New System.Windows.Forms.ComboBox()
        Me.ComboBoxTestKrap = New System.Windows.Forms.ComboBox()
        Me.ComboBoxTestA = New System.Windows.Forms.ComboBox()
        Me.TextBoxPendidikan = New System.Windows.Forms.TextBox()
        Me.TextBoxTenagaKerja = New System.Windows.Forms.TextBox()
        Me.TextBoxDivisi = New System.Windows.Forms.TextBox()
        Me.TextBoxJabatan = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtidus = New System.Windows.Forms.TextBox()
        Me.BottomToolStripPanel = New System.Windows.Forms.ToolStripPanel()
        Me.TopToolStripPanel = New System.Windows.Forms.ToolStripPanel()
        Me.RightToolStripPanel = New System.Windows.Forms.ToolStripPanel()
        Me.LeftToolStripPanel = New System.Windows.Forms.ToolStripPanel()
        Me.ContentPanel = New System.Windows.Forms.ToolStripContentPanel()
        Me.btnsimpan = New System.Windows.Forms.Button()
        Me.Btnbatal = New System.Windows.Forms.Button()
        Me.ComboBoxIDKand = New System.Windows.Forms.ComboBox()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(16, 48)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(101, 16)
        Me.Label1.TabIndex = 97
        Me.Label1.Text = "Nama Kandidat"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(16, 16)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(77, 16)
        Me.Label3.TabIndex = 96
        Me.Label3.Text = "ID Kandidat"
        '
        'TxtNama
        '
        Me.TxtNama.Enabled = False
        Me.TxtNama.Location = New System.Drawing.Point(120, 47)
        Me.TxtNama.Name = "TxtNama"
        Me.TxtNama.Size = New System.Drawing.Size(138, 20)
        Me.TxtNama.TabIndex = 95
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.ComboBoxTestKeprib)
        Me.GroupBox1.Controls.Add(Me.ComboBoxTestArit)
        Me.GroupBox1.Controls.Add(Me.ComboBoxTestKrap)
        Me.GroupBox1.Controls.Add(Me.ComboBoxTestA)
        Me.GroupBox1.Controls.Add(Me.TextBoxPendidikan)
        Me.GroupBox1.Controls.Add(Me.TextBoxTenagaKerja)
        Me.GroupBox1.Controls.Add(Me.TextBoxDivisi)
        Me.GroupBox1.Controls.Add(Me.TextBoxJabatan)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Location = New System.Drawing.Point(19, 79)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(468, 245)
        Me.GroupBox1.TabIndex = 98
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Hasil Seleksi"
        '
        'ComboBoxTestKeprib
        '
        Me.ComboBoxTestKeprib.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxTestKeprib.FormattingEnabled = True
        Me.ComboBoxTestKeprib.Items.AddRange(New Object() {"10", "20", "30", "40", "50", "60", "70", "80", "90", "100"})
        Me.ComboBoxTestKeprib.Location = New System.Drawing.Point(238, 208)
        Me.ComboBoxTestKeprib.Name = "ComboBoxTestKeprib"
        Me.ComboBoxTestKeprib.Size = New System.Drawing.Size(200, 21)
        Me.ComboBoxTestKeprib.TabIndex = 147
        '
        'ComboBoxTestArit
        '
        Me.ComboBoxTestArit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxTestArit.FormattingEnabled = True
        Me.ComboBoxTestArit.Items.AddRange(New Object() {"10", "20", "30", "40", "50", "60", "70", "80", "90", "100"})
        Me.ComboBoxTestArit.Location = New System.Drawing.Point(238, 180)
        Me.ComboBoxTestArit.Name = "ComboBoxTestArit"
        Me.ComboBoxTestArit.Size = New System.Drawing.Size(200, 21)
        Me.ComboBoxTestArit.TabIndex = 146
        '
        'ComboBoxTestKrap
        '
        Me.ComboBoxTestKrap.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxTestKrap.FormattingEnabled = True
        Me.ComboBoxTestKrap.Items.AddRange(New Object() {"10", "20", "30", "40", "50", "60", "70", "80", "90", "100"})
        Me.ComboBoxTestKrap.Location = New System.Drawing.Point(238, 154)
        Me.ComboBoxTestKrap.Name = "ComboBoxTestKrap"
        Me.ComboBoxTestKrap.Size = New System.Drawing.Size(200, 21)
        Me.ComboBoxTestKrap.TabIndex = 145
        '
        'ComboBoxTestA
        '
        Me.ComboBoxTestA.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxTestA.FormattingEnabled = True
        Me.ComboBoxTestA.Items.AddRange(New Object() {"10", "20", "30", "40", "50", "60", "70", "80", "90", "100"})
        Me.ComboBoxTestA.Location = New System.Drawing.Point(238, 125)
        Me.ComboBoxTestA.Name = "ComboBoxTestA"
        Me.ComboBoxTestA.Size = New System.Drawing.Size(200, 21)
        Me.ComboBoxTestA.TabIndex = 144
        '
        'TextBoxPendidikan
        '
        Me.TextBoxPendidikan.Enabled = False
        Me.TextBoxPendidikan.Location = New System.Drawing.Point(238, 98)
        Me.TextBoxPendidikan.Name = "TextBoxPendidikan"
        Me.TextBoxPendidikan.Size = New System.Drawing.Size(200, 20)
        Me.TextBoxPendidikan.TabIndex = 143
        '
        'TextBoxTenagaKerja
        '
        Me.TextBoxTenagaKerja.Enabled = False
        Me.TextBoxTenagaKerja.Location = New System.Drawing.Point(238, 72)
        Me.TextBoxTenagaKerja.Name = "TextBoxTenagaKerja"
        Me.TextBoxTenagaKerja.Size = New System.Drawing.Size(200, 20)
        Me.TextBoxTenagaKerja.TabIndex = 142
        '
        'TextBoxDivisi
        '
        Me.TextBoxDivisi.Enabled = False
        Me.TextBoxDivisi.Location = New System.Drawing.Point(238, 46)
        Me.TextBoxDivisi.Name = "TextBoxDivisi"
        Me.TextBoxDivisi.Size = New System.Drawing.Size(200, 20)
        Me.TextBoxDivisi.TabIndex = 140
        '
        'TextBoxJabatan
        '
        Me.TextBoxJabatan.Enabled = False
        Me.TextBoxJabatan.Location = New System.Drawing.Point(238, 20)
        Me.TextBoxJabatan.Name = "TextBoxJabatan"
        Me.TextBoxJabatan.Size = New System.Drawing.Size(200, 20)
        Me.TextBoxJabatan.TabIndex = 141
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(11, 94)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(76, 16)
        Me.Label4.TabIndex = 138
        Me.Label4.Text = "Pendidikan"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.Black
        Me.Label12.Location = New System.Drawing.Point(11, 208)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(130, 16)
        Me.Label12.TabIndex = 101
        Me.Label12.Text = "Nilai Tes Kpribadian"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.Black
        Me.Label10.Location = New System.Drawing.Point(11, 180)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(124, 16)
        Me.Label10.TabIndex = 113
        Me.Label10.Text = "Nilai Tes Aritmatika"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Black
        Me.Label9.Location = New System.Drawing.Point(11, 154)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(106, 16)
        Me.Label9.TabIndex = 111
        Me.Label9.Text = "Nilai Tes Kraplin"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(11, 125)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(74, 16)
        Me.Label8.TabIndex = 109
        Me.Label8.Text = "Nilai Tes A"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(11, 72)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(90, 16)
        Me.Label5.TabIndex = 101
        Me.Label5.Text = "Tenaga Kerja"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(11, 46)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(76, 16)
        Me.Label6.TabIndex = 99
        Me.Label6.Text = "Kode Divisi"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(11, 20)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(92, 16)
        Me.Label7.TabIndex = 96
        Me.Label7.Text = "Kode Jabatan"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(292, 16)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(53, 16)
        Me.Label2.TabIndex = 100
        Me.Label2.Text = "ID User"
        '
        'txtidus
        '
        Me.txtidus.Enabled = False
        Me.txtidus.Location = New System.Drawing.Point(351, 17)
        Me.txtidus.Name = "txtidus"
        Me.txtidus.Size = New System.Drawing.Size(106, 20)
        Me.txtidus.TabIndex = 99
        '
        'BottomToolStripPanel
        '
        Me.BottomToolStripPanel.Location = New System.Drawing.Point(0, 0)
        Me.BottomToolStripPanel.Name = "BottomToolStripPanel"
        Me.BottomToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal
        Me.BottomToolStripPanel.RowMargin = New System.Windows.Forms.Padding(3, 0, 0, 0)
        Me.BottomToolStripPanel.Size = New System.Drawing.Size(0, 0)
        '
        'TopToolStripPanel
        '
        Me.TopToolStripPanel.Location = New System.Drawing.Point(0, 0)
        Me.TopToolStripPanel.Name = "TopToolStripPanel"
        Me.TopToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal
        Me.TopToolStripPanel.RowMargin = New System.Windows.Forms.Padding(3, 0, 0, 0)
        Me.TopToolStripPanel.Size = New System.Drawing.Size(0, 0)
        '
        'RightToolStripPanel
        '
        Me.RightToolStripPanel.Location = New System.Drawing.Point(0, 0)
        Me.RightToolStripPanel.Name = "RightToolStripPanel"
        Me.RightToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal
        Me.RightToolStripPanel.RowMargin = New System.Windows.Forms.Padding(3, 0, 0, 0)
        Me.RightToolStripPanel.Size = New System.Drawing.Size(0, 0)
        '
        'LeftToolStripPanel
        '
        Me.LeftToolStripPanel.Location = New System.Drawing.Point(0, 0)
        Me.LeftToolStripPanel.Name = "LeftToolStripPanel"
        Me.LeftToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal
        Me.LeftToolStripPanel.RowMargin = New System.Windows.Forms.Padding(3, 0, 0, 0)
        Me.LeftToolStripPanel.Size = New System.Drawing.Size(0, 0)
        '
        'ContentPanel
        '
        Me.ContentPanel.Size = New System.Drawing.Size(150, 150)
        '
        'btnsimpan
        '
        Me.btnsimpan.BackgroundImage = CType(resources.GetObject("btnsimpan.BackgroundImage"), System.Drawing.Image)
        Me.btnsimpan.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnsimpan.Location = New System.Drawing.Point(19, 330)
        Me.btnsimpan.Name = "btnsimpan"
        Me.btnsimpan.Size = New System.Drawing.Size(110, 29)
        Me.btnsimpan.TabIndex = 116
        Me.btnsimpan.Text = "Simpan"
        '
        'Btnbatal
        '
        Me.Btnbatal.BackgroundImage = CType(resources.GetObject("Btnbatal.BackgroundImage"), System.Drawing.Image)
        Me.Btnbatal.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btnbatal.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btnbatal.Location = New System.Drawing.Point(377, 330)
        Me.Btnbatal.Name = "Btnbatal"
        Me.Btnbatal.Size = New System.Drawing.Size(110, 29)
        Me.Btnbatal.TabIndex = 117
        Me.Btnbatal.Text = "Batal"
        '
        'ComboBoxIDKand
        '
        Me.ComboBoxIDKand.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxIDKand.FormattingEnabled = True
        Me.ComboBoxIDKand.Location = New System.Drawing.Point(120, 16)
        Me.ComboBoxIDKand.Name = "ComboBoxIDKand"
        Me.ComboBoxIDKand.Size = New System.Drawing.Size(138, 21)
        Me.ComboBoxIDKand.TabIndex = 145
        '
        'Seleksi
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Teal
        Me.ClientSize = New System.Drawing.Size(507, 366)
        Me.Controls.Add(Me.ComboBoxIDKand)
        Me.Controls.Add(Me.Btnbatal)
        Me.Controls.Add(Me.btnsimpan)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtidus)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.TxtNama)
        Me.MaximumSize = New System.Drawing.Size(523, 405)
        Me.MinimumSize = New System.Drawing.Size(523, 405)
        Me.Name = "Seleksi"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Seleksi"
        Me.GroupBox1.ResumeLayout(false)
        Me.GroupBox1.PerformLayout
        Me.ResumeLayout(false)
        Me.PerformLayout

End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TxtNama As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtidus As System.Windows.Forms.TextBox
    Friend WithEvents BottomToolStripPanel As System.Windows.Forms.ToolStripPanel
    Friend WithEvents TopToolStripPanel As System.Windows.Forms.ToolStripPanel
    Friend WithEvents RightToolStripPanel As System.Windows.Forms.ToolStripPanel
    Friend WithEvents LeftToolStripPanel As System.Windows.Forms.ToolStripPanel
    Friend WithEvents ContentPanel As System.Windows.Forms.ToolStripContentPanel
    Friend WithEvents btnsimpan As System.Windows.Forms.Button
    Friend WithEvents Btnbatal As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents TextBoxPendidikan As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxTenagaKerja As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxDivisi As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxJabatan As System.Windows.Forms.TextBox
    Friend WithEvents ComboBoxTestKeprib As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBoxTestArit As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBoxTestKrap As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBoxTestA As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBoxIDKand As System.Windows.Forms.ComboBox
End Class
