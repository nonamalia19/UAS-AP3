﻿Public Class EditDivisi
    Dim result As Boolean
    Dim div As New Entdivisi
    Dim ctrl As New CtrlDivisi

    Private Sub btnBatal_Click(sender As Object, e As EventArgs) Handles btnBatal.Click
        Me.Dispose()
    End Sub

    Private Sub btnSimpan_Click(sender As Object, e As EventArgs) Handles btnSimpan.Click
        setDiv()
        result = ctrl.editdata(div)
        If result = True Then
            Me.Dispose()
        End If
    End Sub

    Private Sub EditDivisi_Load(sender As Object, e As EventArgs) Handles Me.Load
        div = ctrl.cariDtByKode(kd_divisi)
        setTampilkanData()
    End Sub
    Private Sub setTampilkanData()
        TxtKode.Text = div.kddiv
        txtKode.Enabled = False
        TxtNama.Text = div.nmdiv
        txtjbt.Text = div.jbt

    End Sub
    Private Sub setDiv()
        div.kddiv = TxtKode.Text
        div.nmdiv = TxtNama.Text
        div.jbt = txtjbt.Text

    End Sub


End Class