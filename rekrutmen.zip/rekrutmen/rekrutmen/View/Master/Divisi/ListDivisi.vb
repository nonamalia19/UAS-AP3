﻿Public Class ListDivisi
    Dim ctrl As New CtrlDivisi
    Dim div As New Entdivisi
    Private Sub setdiv(ByVal i As Integer)
        div.kddiv = ""
        div.nmdiv = ""
        div.jbt = ""

    End Sub
    Private Sub ListCustomer_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ctrl.tampilkandt(DGV)
    End Sub

    Private Sub txtCari_TextChanged(sender As Object, e As EventArgs) Handles txtCari.TextChanged
        ctrl.Caridt(txtCari)
    End Sub

    Private Sub btnTambah_Click(sender As Object, e As EventArgs)
        TambahDivisi.Show()
    End Sub

    Private Sub btnEdit_Click(sender As Object, e As EventArgs)
        EditDivisi.Show()
    End Sub

    Private Sub DGV_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DGV.CellClick
        If DGV.Rows.Count > 0 Then
            kd_divisi = DGV.CurrentRow.Cells(0).Value.ToString
        End If
    End Sub

    Private Sub HapusToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HapusToolStripMenuItem.Click
        Dim hasil As DialogResult = MessageBox.Show("Apakah Anda Yakin Akan Mengapus Data " + kd_divisi + "?",
                                                    "Konfirmasi",
                                                    MessageBoxButtons.YesNo)
        If hasil = DialogResult.Yes Then
            ctrl.hapusdata(kd_divisi)
        End If
    End Sub

    Private Sub RefreshToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RefreshToolStripMenuItem.Click
        ctrl.tampilkandt(DGV)
    End Sub

    Private Sub TambahToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TambahToolStripMenuItem.Click
        TambahDivisi.Show()
    End Sub

    Private Sub UpdateToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles UpdateToolStripMenuItem.Click
        kd_divisi = DGV.CurrentRow.Cells(0).Value.ToString
        If (kd_divisi.Trim() = "") Then
            MessageBox.Show("Silahkan pilih salah satu data yang ingin di update")
        Else
            EditDivisi.Show()
        End If

    End Sub
End Class
