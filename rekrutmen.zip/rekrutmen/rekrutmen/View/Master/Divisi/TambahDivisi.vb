﻿Public Class TambahDivisi
    Dim result As Boolean
    Dim div As New Entdivisi
    Dim ctrl As New CtrlDivisi

    Private Sub setdiv()
        div.kddiv = TxtKode.Text
        div.nmdiv = TxtNama.Text
        div.jbt = txtjbt.Text

    End Sub

    Private Sub resetdiv()
        div.kddiv = ""
        div.nmdiv = ""
        div.jbt = ""

    End Sub

    Private Sub btnBatal_Click(sender As Object, e As EventArgs) Handles btnBatal.Click
        Me.Dispose()
    End Sub

    Private Sub simpan_Click(sender As Object, e As EventArgs) Handles simpan.Click
        setdiv()
        result = ctrl.td(div)
        If result = True Then
            Me.Dispose()
        End If
    End Sub
    Private Sub SetLoadDAta()
        TxtKode.Text = ctrl.SetKodeDivisi()
        TxtKode.Enabled = False
    End Sub
    Private Sub TambahDivisi_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        SetLoadDAta()
    End Sub
End Class


