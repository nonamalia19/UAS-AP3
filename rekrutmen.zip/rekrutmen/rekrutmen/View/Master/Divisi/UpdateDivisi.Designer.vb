﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class EditDivisi
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(EditDivisi))
        Me.TxtKode = New System.Windows.Forms.TextBox()
        Me.TxtNama = New System.Windows.Forms.TextBox()
        Me.Btnsimpan = New System.Windows.Forms.Button()
        Me.Btnbatal = New System.Windows.Forms.Button()
        Me.txtjbt = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'TxtKode
        '
        Me.TxtKode.Location = New System.Drawing.Point(139, 17)
        Me.TxtKode.Name = "TxtKode"
        Me.TxtKode.Size = New System.Drawing.Size(217, 20)
        Me.TxtKode.TabIndex = 39
        '
        'TxtNama
        '
        Me.TxtNama.Location = New System.Drawing.Point(139, 43)
        Me.TxtNama.Name = "TxtNama"
        Me.TxtNama.Size = New System.Drawing.Size(217, 20)
        Me.TxtNama.TabIndex = 40
        '
        'Btnsimpan
        '
        Me.Btnsimpan.BackgroundImage = CType(resources.GetObject("Btnsimpan.BackgroundImage"), System.Drawing.Image)
        Me.Btnsimpan.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btnsimpan.Location = New System.Drawing.Point(130, 113)
        Me.Btnsimpan.Name = "Btnsimpan"
        Me.Btnsimpan.Size = New System.Drawing.Size(110, 29)
        Me.Btnsimpan.TabIndex = 41
        Me.Btnsimpan.Text = "Simpan"
        '
        'Btnbatal
        '
        Me.Btnbatal.BackgroundImage = CType(resources.GetObject("Btnbatal.BackgroundImage"), System.Drawing.Image)
        Me.Btnbatal.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btnbatal.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btnbatal.Location = New System.Drawing.Point(246, 113)
        Me.Btnbatal.Name = "Btnbatal"
        Me.Btnbatal.Size = New System.Drawing.Size(110, 29)
        Me.Btnbatal.TabIndex = 42
        Me.Btnbatal.Text = "Batal"
        '
        'txtjbt
        '
        Me.txtjbt.Location = New System.Drawing.Point(139, 69)
        Me.txtjbt.Name = "txtjbt"
        Me.txtjbt.Size = New System.Drawing.Size(217, 20)
        Me.txtjbt.TabIndex = 48
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(9, 14)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(76, 16)
        Me.Label3.TabIndex = 44
        Me.Label3.Text = "Kode Divisi"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(12, 43)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(81, 16)
        Me.Label1.TabIndex = 45
        Me.Label1.Text = "Nama Divisi"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(12, 68)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(57, 16)
        Me.Label2.TabIndex = 47
        Me.Label2.Text = "Jabatan"
        '
        'EditDivisi
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Teal
        Me.ClientSize = New System.Drawing.Size(384, 156)
        Me.Controls.Add(Me.txtjbt)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Btnbatal)
        Me.Controls.Add(Me.Btnsimpan)
        Me.Controls.Add(Me.TxtNama)
        Me.Controls.Add(Me.TxtKode)
        Me.ForeColor = System.Drawing.Color.Black
        Me.Name = "EditDivisi"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "EditDivisi"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TxtKode As System.Windows.Forms.TextBox
    Friend WithEvents TxtNama As System.Windows.Forms.TextBox
    Friend WithEvents Btnsimpan As System.Windows.Forms.Button
    Friend WithEvents Btnbatal As System.Windows.Forms.Button
    Friend WithEvents txtjbt As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
End Class
