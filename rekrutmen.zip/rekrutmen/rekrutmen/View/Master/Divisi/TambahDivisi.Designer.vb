﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class TambahDivisi
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(TambahDivisi))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Btnbatal = New System.Windows.Forms.Button()
        Me.simpan = New System.Windows.Forms.Button()
        Me.TxtNama = New System.Windows.Forms.TextBox()
        Me.TxtKode = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtjbt = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(14, 45)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(81, 16)
        Me.Label1.TabIndex = 35
        Me.Label1.Text = "Nama Divisi"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(14, 16)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(76, 16)
        Me.Label3.TabIndex = 34
        Me.Label3.Text = "Kode Divisi"
        '
        'Btnbatal
        '
        Me.Btnbatal.BackgroundImage = CType(resources.GetObject("Btnbatal.BackgroundImage"), System.Drawing.Image)
        Me.Btnbatal.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btnbatal.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btnbatal.Location = New System.Drawing.Point(246, 106)
        Me.Btnbatal.Name = "Btnbatal"
        Me.Btnbatal.Size = New System.Drawing.Size(110, 29)
        Me.Btnbatal.TabIndex = 32
        Me.Btnbatal.Text = "Batal"
        '
        'simpan
        '
        Me.simpan.BackgroundImage = CType(resources.GetObject("simpan.BackgroundImage"), System.Drawing.Image)
        Me.simpan.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.simpan.Location = New System.Drawing.Point(130, 106)
        Me.simpan.Name = "simpan"
        Me.simpan.Size = New System.Drawing.Size(110, 29)
        Me.simpan.TabIndex = 31
        Me.simpan.Text = "Simpan"
        '
        'TxtNama
        '
        Me.TxtNama.Location = New System.Drawing.Point(130, 41)
        Me.TxtNama.Name = "TxtNama"
        Me.TxtNama.Size = New System.Drawing.Size(226, 20)
        Me.TxtNama.TabIndex = 30
        '
        'TxtKode
        '
        Me.TxtKode.Location = New System.Drawing.Point(130, 15)
        Me.TxtKode.Name = "TxtKode"
        Me.TxtKode.Size = New System.Drawing.Size(226, 20)
        Me.TxtKode.TabIndex = 29
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(14, 71)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(57, 16)
        Me.Label2.TabIndex = 37
        Me.Label2.Text = "Jabatan"
        '
        'txtjbt
        '
        Me.txtjbt.Location = New System.Drawing.Point(130, 67)
        Me.txtjbt.Name = "txtjbt"
        Me.txtjbt.Size = New System.Drawing.Size(226, 20)
        Me.txtjbt.TabIndex = 38
        '
        'TambahDivisi
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Teal
        Me.ClientSize = New System.Drawing.Size(368, 150)
        Me.Controls.Add(Me.txtjbt)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Btnbatal)
        Me.Controls.Add(Me.simpan)
        Me.Controls.Add(Me.TxtNama)
        Me.Controls.Add(Me.TxtKode)
        Me.ForeColor = System.Drawing.Color.Black
        Me.MaximumSize = New System.Drawing.Size(384, 373)
        Me.MinimumSize = New System.Drawing.Size(384, 188)
        Me.Name = "TambahDivisi"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "tbdivisi"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Btnbatal As System.Windows.Forms.Button
    Friend WithEvents simpan As System.Windows.Forms.Button
    Friend WithEvents TxtNama As System.Windows.Forms.TextBox
    Friend WithEvents TxtKode As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtjbt As System.Windows.Forms.TextBox
End Class
