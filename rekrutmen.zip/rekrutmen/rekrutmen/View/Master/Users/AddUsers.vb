﻿Public Class AddUsers
    Dim entuser As New EntUsers
    Dim result As Boolean
    Dim ctrl As New CtrlUsers

    Private Sub SetUser()
        entuser.idUser = txtID.Text
        entuser.namaUser = txtNama.Text
        entuser.password = txtPass.Text
        entuser.username = txtUserLogin.Text

    End Sub
    Private Sub Btnsimpan_Click(sender As Object, e As EventArgs) Handles Btnsimpan.Click

        SetUser()
        If FlagSimpanUpdate = "ADD" Then
            result = ctrl.td(entuser)
        ElseIf FlagSimpanUpdate = "UPDATE" Then
            result = ctrl.editdata(entuser)
        End If

        If result = True Then
            Me.Dispose()
        End If
    End Sub
    Private Sub SetLoadDAta()
        txtID.Text = ctrl.SetKodeUser()
        txtID.Enabled = False
    End Sub

    Private Sub setTampilkanData()
        txtID.Text = entuser.idUser
        txtID.Enabled = False
        txtNama.Text = entuser.namaUser
        txtPass.Text = entuser.password
        txtUserLogin.Text = entuser.username

    End Sub
    Private Sub AddUsers_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If FlagSimpanUpdate = "ADD" Then
            SetLoadDAta()
        ElseIf FlagSimpanUpdate = "UPDATE" Then
            entuser = ctrl.cariDtByKode(kd_divisi)
            setTampilkanData()
        End If

    End Sub
End Class