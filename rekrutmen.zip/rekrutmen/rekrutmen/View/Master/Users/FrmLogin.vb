﻿Public Class FrmLogin
    Dim ctrl As New CtrlUsers
    Dim user As New EntUsers
    Dim menustrip1 As Menu
   
    Private Sub Cancel_Click(sender As Object, e As EventArgs) Handles Cancel.Click
        Me.Close()
    End Sub

    Private Sub btnok_Click(sender As Object, e As EventArgs) Handles btnOK.Click
        user = ctrl.cariUser(txtusers.Text, txtpassword.Text)
        If user.idUser <> "" Then
            menustrip1 = New Menu(user)
            menustrip1.Show()
            Me.Hide()
        End If
    End Sub
End Class