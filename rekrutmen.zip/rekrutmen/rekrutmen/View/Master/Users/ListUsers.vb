﻿Public Class ListUsers
    Dim ctrl As New CtrlUsers
    Dim div As New EntUsers
    Private Sub AddToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AddToolStripMenuItem.Click
        FlagSimpanUpdate = "ADD"
        AddUsers.Show()
    End Sub

    Private Sub RefreshToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RefreshToolStripMenuItem.Click
        ctrl.tampilkandt(DGV)
    End Sub

    Private Sub ListUsers_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ctrl.tampilkandt(DGV)
    End Sub

    Private Sub UpdateToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles UpdateToolStripMenuItem.Click
        If (kd_divisi.Trim() = "") Then
            MessageBox.Show("Silahkan pilih salah satu data yang ingin di update")
        Else
            FlagSimpanUpdate = "UPDATE"
            AddUsers.Show()
        End If

    End Sub
    Private Sub DGV_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DGV.CellClick
        If DGV.Rows.Count > 0 Then
            kd_divisi = DGV.CurrentRow.Cells(0).Value.ToString
        End If
    End Sub
    Private Sub DeleteToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DeleteToolStripMenuItem.Click
        Dim hasil As DialogResult = MessageBox.Show("Apakah Anda Yakin Akan Mengapus Data " + kd_divisi + "?",
                                                    "Konfirmasi",
                                                    MessageBoxButtons.YesNo)
        If hasil = DialogResult.Yes Then
            ctrl.hapusdata(kd_divisi)
        End If
    End Sub
End Class