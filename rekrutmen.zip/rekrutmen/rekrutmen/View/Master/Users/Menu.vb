﻿Public Class Menu
    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.

    End Sub
    Public Sub New(ByVal user As EntUsers)

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        IdUserToolStripMenuItem.Text = user.idUser
        namaUserLogToolStripMenuItem.Text = user.namaUser
        id_user = user.idUser


    End Sub
    Private Sub LogoutToolStripMenuItem_Click_1(sender As Object, e As EventArgs)
        Me.Close()
    End Sub

    Private Sub jabatan_Click(sender As Object, e As EventArgs)
        ListJabatan.Show()

    End Sub

    Private Sub kandidat_Click(sender As Object, e As EventArgs)
        ListKandidat.Show()
    End Sub

    Private Sub Divisi_Click(sender As Object, e As EventArgs)
        ListDivisi.Show()
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs)
        ListKandidat.Show()
    End Sub
    Private Sub TreeView1_NodeMouseDoubleClick(sender As Object, e As TreeNodeMouseClickEventArgs) Handles TreeView1.NodeMouseDoubleClick
        If e.Node.Text.Equals("Close") Then
            Me.Close()
        ElseIf e.Node.Text.Equals("Divisi") Then
            If MenuDivisi = "True" Then
                ListDivisi.Show()
            Else
                MessageBox.Show("Anda tidak memiliki akses pada menu ini")
            End If

        ElseIf e.Node.Text.Equals("Jabatan") Then
            If MenuJabatan = "True" Then
                ListJabatan.Show()
            Else
                MessageBox.Show("Anda tidak memiliki akses pada menu ini")
            End If

        ElseIf e.Node.Text.Equals("Kandidat") Then
            If MenuKandidat = "True" Then
                ListKandidat.Show()
            Else
                MessageBox.Show("Anda tidak memiliki akses pada menu ini")
            End If

        ElseIf e.Node.Text.Equals("Users") Then
            If MenuUsers = "True" Then
                ListUsers.Show()
            Else
                MessageBox.Show("Anda tidak memiliki akses pada menu ini")
            End If

        ElseIf e.Node.Text.Equals("Daftar Lowongan") Then
            If MenuLowongan = "True" Then
                ListDaftar.Show()
            Else
                MessageBox.Show("Anda tidak memiliki akses pada menu ini")
            End If
        ElseIf e.Node.Text.Equals("Seleksi") Then
            If MenuSeleksi = "True" Then
                ListSeleksi.Show()
            Else
                MessageBox.Show("Anda tidak memiliki akses pada menu ini")
            End If
        ElseIf e.Node.Text.Equals("Setting Akses") Then
            If MenuUtility = "True" Then
                SettAccess.Show()
            Else
                MessageBox.Show("Anda tidak memiliki akses pada menu ini")
            End If
        ElseIf e.Node.Text.Equals("Help") Then
            MessageBox.Show("Coming Soon")
        ElseIf e.Node.Text.Equals("About") Then
            MessageBox.Show("Coming Soon")
        End If

    End Sub

    Private Sub LogoutStripMenuItem1_Click(sender As Object, e As EventArgs) Handles LogoutStripMenuItem1.Click
        Dim lg As FrmLogin = New FrmLogin()
        lg.Show()
        Me.Close()
    End Sub

  
    Private Sub Menu_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class