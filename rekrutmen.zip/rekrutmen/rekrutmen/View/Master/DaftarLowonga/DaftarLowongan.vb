﻿Public Class DaftarLowongan
    Dim result As Boolean
    Dim df As New EntDaftar
    Dim ctrldf As New CtrlDaftar

    Private Sub SetTampilkanDataUpdate()
        Try
            txtid.Text = df.id_low.Trim()
            txtid.Enabled = False
            Txtnama.Text = df.nm_low.Trim()
            Txtjbt.Text = df.jbt.Trim()
            Txtdiv.Text = df.div.Trim()
            Txtuser.Text = df.user.Trim()
            txttg.Text = df.tg_kerja.Trim()

        Catch ex As Exception
            MessageBox.Show(ex.ToString())
            Return
        End Try

    End Sub

    Private Sub Simpan_Click(sender As Object, e As EventArgs) Handles Simpan.Click
        SetSimpanDf()
        If FlagSimpanUpdate.ToUpper().Trim() = "ADD" Then
            If (ctrldf.td(df)) Then
                result = True
            End If
        End If

        If FlagSimpanUpdate.ToUpper().Trim() = "UPDATE" Then
            If ctrldf.editdata(df) Then
                result = True
            End If
        End If

        If result = True Then
            Me.Dispose()
            ListDaftar.Focus()
        End If
    End Sub
    Private Sub SetIDlowongan()
        txtid.Text = ctrldf.Setidlowongan()
        txtid.Enabled = False
    End Sub

    Private Sub daftarlowonganForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If FlagSimpanUpdate.ToUpper().Trim() = "ADD" Then
            SetIDlowongan()
        ElseIf FlagSimpanUpdate.ToUpper().Trim() = "UPDATE" Then
            df = ctrldf.cariDtByKode(id_lowongan)
            SetTampilkanDataUpdate()
        End If
    End Sub

        
    Private Sub SetSimpanDf()
        Try
            df.id_low = txtid.Text
            df.nm_low = Txtnama.Text
            df.jbt = Txtjbt.Text
            df.div = Txtdiv.Text
            df.user = Txtuser.Text
            df.tg_kerja = txttg.Text

        Catch ex As Exception
            MessageBox.Show(ex.ToString())
            Return
        End Try

    End Sub



    Private Sub setdf()
        df.id_low = txtid.Text
        df.nm_low = Txtnama.Text
        df.jbt = Txtjbt.Text
        df.div = Txtdiv.Text
        df.user = Txtuser.Text
        df.tg_kerja = txttg.Text

    End Sub
    Private Sub resetdf()
        df.id_low = ""
        df.nm_low = ""
        df.jbt = ""
        df.div = ""
        df.user = ""
        df.tg_kerja = ""
    End Sub
End Class