﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DaftarLowongan
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(DaftarLowongan))
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.txttg = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Txtuser = New System.Windows.Forms.TextBox()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Txtdiv = New System.Windows.Forms.TextBox()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Txtjbt = New System.Windows.Forms.TextBox()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Txtnama = New System.Windows.Forms.TextBox()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.txtid = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Batal = New System.Windows.Forms.Button()
        Me.Simpan = New System.Windows.Forms.Button()
        Me.GroupBox7.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.txttg)
        Me.GroupBox7.Controls.Add(Me.Label2)
        Me.GroupBox7.Controls.Add(Me.Txtuser)
        Me.GroupBox7.Controls.Add(Me.Label48)
        Me.GroupBox7.Controls.Add(Me.Txtdiv)
        Me.GroupBox7.Controls.Add(Me.Label49)
        Me.GroupBox7.Controls.Add(Me.Txtjbt)
        Me.GroupBox7.Controls.Add(Me.Label50)
        Me.GroupBox7.Controls.Add(Me.Txtnama)
        Me.GroupBox7.Controls.Add(Me.Label52)
        Me.GroupBox7.Location = New System.Drawing.Point(12, 52)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(307, 172)
        Me.GroupBox7.TabIndex = 3
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Daftar Lowongan"
        '
        'txttg
        '
        Me.txttg.Location = New System.Drawing.Point(130, 124)
        Me.txttg.Name = "txttg"
        Me.txttg.Size = New System.Drawing.Size(159, 20)
        Me.txttg.TabIndex = 112
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label2.Location = New System.Drawing.Point(6, 124)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(90, 16)
        Me.Label2.TabIndex = 111
        Me.Label2.Text = "Tenaga Kerja"
        '
        'Txtuser
        '
        Me.Txtuser.Location = New System.Drawing.Point(130, 96)
        Me.Txtuser.Name = "Txtuser"
        Me.Txtuser.Size = New System.Drawing.Size(159, 20)
        Me.Txtuser.TabIndex = 110
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label48.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label48.Location = New System.Drawing.Point(7, 101)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(44, 16)
        Me.Label48.TabIndex = 109
        Me.Label48.Text = "Users"
        '
        'Txtdiv
        '
        Me.Txtdiv.Location = New System.Drawing.Point(130, 68)
        Me.Txtdiv.Name = "Txtdiv"
        Me.Txtdiv.Size = New System.Drawing.Size(159, 20)
        Me.Txtdiv.TabIndex = 108
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label49.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label49.Location = New System.Drawing.Point(7, 74)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(41, 16)
        Me.Label49.TabIndex = 107
        Me.Label49.Text = "Divisi"
        '
        'Txtjbt
        '
        Me.Txtjbt.Location = New System.Drawing.Point(130, 42)
        Me.Txtjbt.Name = "Txtjbt"
        Me.Txtjbt.Size = New System.Drawing.Size(159, 20)
        Me.Txtjbt.TabIndex = 106
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label50.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label50.Location = New System.Drawing.Point(6, 48)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(57, 16)
        Me.Label50.TabIndex = 101
        Me.Label50.Text = "Jabatan"
        '
        'Txtnama
        '
        Me.Txtnama.Location = New System.Drawing.Point(130, 16)
        Me.Txtnama.Name = "Txtnama"
        Me.Txtnama.Size = New System.Drawing.Size(159, 20)
        Me.Txtnama.TabIndex = 97
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label52.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label52.Location = New System.Drawing.Point(6, 21)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(110, 16)
        Me.Label52.TabIndex = 96
        Me.Label52.Text = "Nama Lowongan"
        '
        'txtid
        '
        Me.txtid.Location = New System.Drawing.Point(142, 20)
        Me.txtid.Name = "txtid"
        Me.txtid.Size = New System.Drawing.Size(159, 20)
        Me.txtid.TabIndex = 99
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label1.Location = New System.Drawing.Point(18, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(86, 16)
        Me.Label1.TabIndex = 98
        Me.Label1.Text = "ID Lowongan"
        '
        'Batal
        '
        Me.Batal.BackgroundImage = CType(resources.GetObject("Batal.BackgroundImage"), System.Drawing.Image)
        Me.Batal.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Batal.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Batal.Location = New System.Drawing.Point(209, 236)
        Me.Batal.Name = "Batal"
        Me.Batal.Size = New System.Drawing.Size(110, 29)
        Me.Batal.TabIndex = 120
        Me.Batal.Text = "Batal"
        '
        'Simpan
        '
        Me.Simpan.BackgroundImage = CType(resources.GetObject("Simpan.BackgroundImage"), System.Drawing.Image)
        Me.Simpan.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Simpan.Location = New System.Drawing.Point(15, 236)
        Me.Simpan.Name = "Simpan"
        Me.Simpan.Size = New System.Drawing.Size(110, 29)
        Me.Simpan.TabIndex = 119
        Me.Simpan.Text = "Simpan"
        '
        'DaftarLowongan
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Teal
        Me.ClientSize = New System.Drawing.Size(332, 275)
        Me.Controls.Add(Me.Batal)
        Me.Controls.Add(Me.Simpan)
        Me.Controls.Add(Me.txtid)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.GroupBox7)
        Me.MaximumSize = New System.Drawing.Size(348, 314)
        Me.MinimumSize = New System.Drawing.Size(348, 314)
        Me.Name = "DaftarLowongan"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Daftar Lowongan"
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents Txtuser As System.Windows.Forms.TextBox
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Txtdiv As System.Windows.Forms.TextBox
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents Txtjbt As System.Windows.Forms.TextBox
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents Txtnama As System.Windows.Forms.TextBox
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents txtid As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txttg As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Batal As System.Windows.Forms.Button
    Friend WithEvents Simpan As System.Windows.Forms.Button
End Class
