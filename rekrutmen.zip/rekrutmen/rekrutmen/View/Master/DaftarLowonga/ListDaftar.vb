﻿Public Class ListDaftar
    Dim ctrl As New CtrlDaftar

    Private Sub ListCustomer_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ctrl.tampilkandt(DGV)
    End Sub

    Private Sub txtCari_TextChanged(sender As Object, e As EventArgs) Handles txtCari.TextChanged
        ctrl.Caridt(txtCari)
    End Sub
    Private Sub DGV_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DGV.CellClick
        If DGV.Rows.Count > 0 Then
            id_lowongan = DGV.CurrentRow.Cells(0).Value.ToString
        End If
    End Sub

    Private Sub AddToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AddToolStripMenuItem.Click
        FlagSimpanUpdate = "Add"
        DaftarLowongan.Show()
    End Sub

    Private Sub UpdateToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles UpdateToolStripMenuItem.Click
        If (id_lowongan.Trim() = "") Then
            MessageBox.Show("Silahkan pilih salah satu data yang ingin di update")
        Else
            FlagSimpanUpdate = "Update"
            DaftarLowongan.Show()
        End If

    End Sub

    Private Sub RefreshToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RefreshToolStripMenuItem.Click
        ctrl.tampilkandt(DGV)
    End Sub

    Private Sub DeleteToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DeletToolStripMenuItem.Click
        Dim hasil As DialogResult = MessageBox.Show("Apakah Anda Yakin Akan Mengapus Data " + id_kandidat + "?",
                                                    "Konfirmasi",
                                                    MessageBoxButtons.YesNo)
        If hasil = DialogResult.Yes Then
            ctrl.hapusdata(id_lowongan)

        End If
    End Sub
End Class