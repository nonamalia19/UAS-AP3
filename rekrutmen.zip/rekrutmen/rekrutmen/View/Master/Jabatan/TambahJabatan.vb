﻿Public Class TambahJabatan
    Dim result As Boolean
    Dim jbt As New Entjabatan
    Dim ctrl As New CtrlJabatan

    Private Sub setjbt()
        jbt.kdjbt = TxtKode.Text
        jbt.nmjbt = TxtNama.Text

    End Sub

    Private Sub resetjbt()
        jbt.kdjbt = ""
        jbt.nmjbt = ""
    End Sub

    Private Sub btnBatal_Click(sender As Object, e As EventArgs) Handles Btnbatal.Click
        Me.Dispose()
    End Sub

    Private Sub simpan_Click(sender As Object, e As EventArgs) Handles Btnsimpan.Click
        resetjbt()
        setjbt()
        result = ctrl.td(jbt)
        If result = True Then
            Me.Dispose()
        End If
    End Sub
End Class