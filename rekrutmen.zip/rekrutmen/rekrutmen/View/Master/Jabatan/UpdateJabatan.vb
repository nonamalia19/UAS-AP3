﻿Public Class UpdateJabatan
    Dim result As Boolean
    Dim jbt As New Entjabatan
    Dim ctrl As New CtrlJabatan

    Private Sub btnBatal_Click(sender As Object, e As EventArgs) Handles Btnbatal.Click
        Me.Dispose()
    End Sub

    Private Sub btnSimpan_Click(sender As Object, e As EventArgs) Handles Btnsimpan.Click
        setjbt()
        result = ctrl.editdata(jbt)
        If result = True Then
            Me.Dispose()
        End If
    End Sub

    Private Sub EditJabatan_Load(sender As Object, e As EventArgs) Handles Me.Load
        jbt = ctrl.cariDtByKode(kd_jabatan)
        setTampilkanData()
    End Sub
    Private Sub setTampilkanData()
        TxtKode.Text = jbt.kdjbt
        txtKode.Enabled = False
        TxtNama.Text = jbt.nmjbt
    End Sub
    Private Sub setjbt()
        jbt.kdjbt = TxtKode.Text
        jbt.nmjbt = TxtNama.Text
    End Sub

End Class