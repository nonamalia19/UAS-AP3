﻿Public Class EntUsers
    Private id_user As String 'field id_user
    Private nm_user As String 'field nm_user
    Private user_login As String 'field username'
    Private pass As String 'field pass'

    Public Property password() As String
        Get
            Return pass
        End Get
        Set(ByVal value As String)
            pass = value
        End Set
    End Property

    Public Property username() As String
        Get
            Return user_login
        End Get
        Set(ByVal value As String)
            user_login = value
        End Set
    End Property

    Public Property namaUser() As String
        Get
            Return nm_user
        End Get
        Set(ByVal value As String)
            nm_user = value
        End Set
    End Property

    Public Property idUser() As String
        Get
            Return id_user
        End Get
        Set(ByVal value As String)
            id_user = value
        End Set
    End Property


End Class
