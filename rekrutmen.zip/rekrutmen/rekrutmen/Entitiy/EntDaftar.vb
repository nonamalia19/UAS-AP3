﻿Public Class EntDaftar
    Private id_lowongan As String
    Private nm_lowongan As String
    Private jabatan As String
    Private divisi As String
    Private users As String
    Private tenaga_kerja As String

    Public Property tg_kerja() As String
        Get
            Return tenaga_kerja
        End Get
        Set(ByVal value As String)
            tenaga_kerja = value
        End Set
    End Property

    Public Property nm_low() As String
        Get
            Return nm_lowongan
        End Get
        Set(ByVal value As String)
            nm_lowongan = value
        End Set
    End Property

    Public Property jbt() As String
        Get
            Return jabatan
        End Get
        Set(ByVal value As String)
            jabatan = value
        End Set
    End Property

    Public Property div() As String
        Get
            Return divisi
        End Get
        Set(ByVal value As String)
            divisi = value
        End Set
    End Property

    Public Property user() As String
        Get
            Return users
        End Get
        Set(ByVal value As String)
            users = value
        End Set
    End Property

    Public Property id_low() As String
        Get
            Return id_lowongan
        End Get
        Set(ByVal value As String)
            id_lowongan = value
        End Set
    End Property
End Class
