﻿Public Class Enthistory_keluarga

    Private id_kandidat As String
    Private id_hiskel As String
    Private nm_istri_suami As String
    Private nm_anak1 As String
    Private nm_anak2 As String
    Private nm_anak3 As String
    Private usia_istri_suami As String
    Private usia_anak1 As String
    Private usia_anak2 As String
    Private usia_anak3 As String
    Private pend_istri_suami As String
    Private pend_anak1 As String
    Private pend_anak2 As String
    Private pend_anak3 As String
    Private pek_istri_suami As String
    Private pek_anak1 As String
    Private pek_anak2 As String
    Private pek_anak3 As String

    Public Property IDKandidat() As String
        Get
            Return id_kandidat
        End Get
        Set(ByVal value As String)
            id_kandidat = value
        End Set
    End Property

    Public Property IDHiskel() As String
        Get
            Return id_hiskel
        End Get
        Set(ByVal value As String)
            id_hiskel = value
        End Set
    End Property

    Public Property NamaIstriAtuSuami() As String
        Get
            Return nm_istri_suami
        End Get
        Set(ByVal value As String)
            nm_istri_suami = value
        End Set
    End Property

    Public Property NamaAnak1() As String
        Get
            Return nm_anak1
        End Get
        Set(ByVal value As String)
            nm_anak1 = value
        End Set
    End Property

    Public Property NamaAnak2() As String
        Get
            Return nm_anak2
        End Get
        Set(ByVal value As String)
            nm_anak2 = value
        End Set
    End Property

    Public Property NamaAnak3() As String
        Get
            Return nm_anak3
        End Get
        Set(ByVal value As String)
            nm_anak3 = value
        End Set
    End Property

    Public Property UsiaIstriSuami() As String
        Get
            Return usia_istri_suami
        End Get
        Set(ByVal value As String)
            usia_istri_suami = value
        End Set
    End Property

    Public Property UsiaAnak1() As String
        Get
            Return usia_anak1
        End Get
        Set(ByVal value As String)
            usia_anak1 = value
        End Set
    End Property

    Public Property UsiaAnak2() As String
        Get
            Return usia_anak2
        End Get
        Set(ByVal value As String)
            usia_anak2 = value
        End Set
    End Property

    Public Property UsiaAnak3() As String
        Get
            Return usia_anak3
        End Get
        Set(ByVal value As String)
            usia_anak3 = value
        End Set
    End Property

    Public Property PendidikanIstriSuami() As String
        Get
            Return pend_istri_suami
        End Get
        Set(ByVal value As String)
            pend_istri_suami = value
        End Set
    End Property

    Public Property PendidikanAnak1() As String
        Get
            Return pend_anak1
        End Get
        Set(ByVal value As String)
            pend_anak1 = value
        End Set
    End Property

    Public Property PendidikanAnak2() As String
        Get
            Return pend_anak2
        End Get
        Set(ByVal value As String)
            pend_anak2 = value
        End Set
    End Property

    Public Property PendidikanAnak3() As String
        Get
            Return pend_anak3
        End Get
        Set(ByVal value As String)
            pend_anak3 = value
        End Set
    End Property

    Public Property PekertjaanIstriSuami() As String
        Get
            Return pek_istri_suami
        End Get
        Set(ByVal value As String)
            pek_istri_suami = value
        End Set
    End Property

    Public Property PekerjaanAnak1() As String
        Get
            Return pek_anak1
        End Get
        Set(ByVal value As String)
            pek_anak1 = value
        End Set
    End Property

    Public Property PekerjaanAnak2() As String
        Get
            Return pek_anak2
        End Get
        Set(ByVal value As String)
            pek_anak2 = value
        End Set
    End Property

    Public Property PekerjaanAnak3() As String
        Get
            Return pek_anak3
        End Get
        Set(ByVal value As String)
            pek_anak3 = value
        End Set
    End Property


End Class
