﻿Public Class Entdivisi
    Private kd_divisi As String
    Private nm_divisi As String
    Private jabatan As String

    Public Property jbt() As String
        Get
            Return jabatan
        End Get
        Set(ByVal value As String)
            jabatan = value
        End Set
    End Property

    Public Property nmdiv() As String
        Get
            Return nm_divisi
        End Get
        Set(ByVal value As String)
            nm_divisi = value
        End Set
    End Property

    Public Property kddiv() As String
        Get
            Return kd_divisi
        End Get
        Set(ByVal value As String)
            kd_divisi = value
        End Set
    End Property


End Class
