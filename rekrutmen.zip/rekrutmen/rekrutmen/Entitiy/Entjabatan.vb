﻿Public Class Entjabatan
    Private kd_jabatan As String
    Private nm_jabatan As String

    Public Property nmjbt() As String
        Get
            Return nm_jabatan
        End Get
        Set(ByVal value As String)
            nm_jabatan = value
        End Set
    End Property

    Public Property kdjbt() As String
        Get
            Return kd_jabatan
        End Get
        Set(ByVal value As String)
            kd_jabatan = value
        End Set
    End Property

End Class
