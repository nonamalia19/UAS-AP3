﻿Public Class EntKandidat
    Private kd_kandidat As String
    Private nm_kandidat As String
    Private tmp_lahir As String
    Private tgl_lahir As String
    Private agama As String
    Private pendidikan As String
    Private j_kelamin As String
    Private no_ktp As String
    Private alamat As String
    Private no_tlp As String
    Private no_rek As String
    Private no_bpjstk As String
    Private no_npwp As String
    Private masaberlaku_ktp As String
    Private tgl_masuk As String
    Private tenaga_kerja As String
    Private area_penempatan As String
    Private kd_jabatan As String
    Private kd_divisi As String
    Private sttus_pernikahan As String
    Private sttus_kandidat As String
    Private id_lowongan As String

    Public Property KodeDivisi() As String
        Get
            Return kd_divisi
        End Get
        Set(ByVal value As String)
            kd_divisi = value
        End Set
    End Property

    Public Property KodeJabatan() As String
        Get
            Return kd_jabatan
        End Get
        Set(ByVal value As String)
            kd_jabatan = value
        End Set
    End Property

    Public Property AreaPenempatan() As String
        Get
            Return area_penempatan
        End Get
        Set(ByVal value As String)
            area_penempatan = value
        End Set
    End Property

    Public Property TenagaKerja() As String
        Get
            Return tenaga_kerja
        End Get
        Set(ByVal value As String)
            tenaga_kerja = value
        End Set
    End Property

    Public Property TglMasuk() As String
        Get
            Return tgl_masuk
        End Get
        Set(ByVal value As String)
            tgl_masuk = value
        End Set
    End Property

    Public Property MassaKtp() As String
        Get
            Return masaberlaku_ktp
        End Get
        Set(ByVal value As String)
            masaberlaku_ktp = value
        End Set
    End Property

    Public Property NoNpwp() As String
        Get
            Return no_npwp
        End Get
        Set(ByVal value As String)
            no_npwp = value
        End Set
    End Property

    Public Property NoBpjs() As String
        Get
            Return no_bpjstk
        End Get
        Set(ByVal value As String)
            no_bpjstk = value
        End Set
    End Property

    Public Property NoRek() As String
        Get
            Return no_rek
        End Get
        Set(ByVal value As String)
            no_rek = value
        End Set
    End Property

    Public Property NoTelp() As String
        Get
            Return no_tlp
        End Get
        Set(ByVal value As String)
            no_tlp = value
        End Set
    End Property

    Public Property AlamatKandidat() As String
        Get
            Return alamat
        End Get
        Set(ByVal value As String)
            alamat = value
        End Set
    End Property

    Public Property NoKtp() As String
        Get
            Return no_ktp
        End Get
        Set(ByVal value As String)
            no_ktp = value
        End Set
    End Property

    Public Property JenisKelamin() As String
        Get
            Return j_kelamin
        End Get
        Set(ByVal value As String)
            j_kelamin = value
        End Set
    End Property

    Public Property PendidikanKdt() As String
        Get
            Return pendidikan
        End Get
        Set(ByVal value As String)
            pendidikan = value
        End Set
    End Property

    Public Property AgamaKdt() As String
        Get
            Return agama
        End Get
        Set(ByVal value As String)
            agama = value
        End Set
    End Property

    Public Property TanggalLhr() As String
        Get
            Return tgl_lahir
        End Get
        Set(ByVal value As String)
            tgl_lahir = value
        End Set
    End Property

    Public Property TmpatLahir() As String
        Get
            Return tmp_lahir
        End Get
        Set(ByVal value As String)
            tmp_lahir = value
        End Set
    End Property

    Public Property NamaKandidat() As String
        Get
            Return nm_kandidat
        End Get
        Set(ByVal value As String)
            nm_kandidat = value
        End Set
    End Property

    Public Property IDKandidat() As String
        Get
            Return kd_kandidat
        End Get
        Set(ByVal value As String)
            kd_kandidat = value
        End Set
    End Property

    Public Property StatusKawin() As String
        Get
            Return sttus_pernikahan
        End Get
        Set(ByVal value As String)
            sttus_pernikahan = value
        End Set
    End Property

    Public Property StatusKandidat() As String
        Get
            Return sttus_kandidat
        End Get
        Set(ByVal value As String)
            sttus_kandidat = value
        End Set
    End Property

    Public Property IDLowongan() As String
        Get
            Return id_lowongan
        End Get
        Set(ByVal value As String)
            id_lowongan = value
        End Set
    End Property

    '---------------------------------------------
End Class
