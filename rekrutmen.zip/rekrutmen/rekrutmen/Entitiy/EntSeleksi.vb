﻿Public Class EntSeleksi
    Private id_seleksi As String
    Private nm_kandidat As String
    Private jabatan As String
    Private divisi As String
    Private pendidikan As String
    Private tenaga_kerja As String
    Private nilai_tesA As String
    Private nilai_teskraeplin As String
    Private nilai_tesarimatika As String
    Private nilai_teskpribadian As String
    Private id_user As String

    Public Property id_use() As String
        Get
            Return id_user
        End Get
        Set(ByVal value As String)
            id_user = value
        End Set
    End Property

    Public Property nm_kdt() As String
        Get
            Return nm_kandidat
        End Get
        Set(ByVal value As String)
            nm_kandidat = value
        End Set
    End Property

    Public Property jbt() As String
        Get
            Return jabatan
        End Get
        Set(ByVal value As String)
            jabatan = value
        End Set
    End Property

    Public Property div() As String
        Get
            Return divisi
        End Get
        Set(ByVal value As String)
            divisi = value
        End Set
    End Property

    Public Property pend() As String
        Get
            Return pendidikan
        End Get
        Set(ByVal value As String)
            pendidikan = value
        End Set
    End Property

    Public Property tg_kerja() As String
        Get
            Return tenaga_kerja
        End Get
        Set(ByVal value As String)
            tenaga_kerja = value
        End Set
    End Property

    Public Property N_TestA() As String
        Get
            Return nilai_tesA
        End Get
        Set(ByVal value As String)
            nilai_tesA = value
        End Set
    End Property

    Public Property N_TestKraeplin() As String
        Get
            Return nilai_teskraeplin
        End Get
        Set(ByVal value As String)
            nilai_teskraeplin = value
        End Set
    End Property

    Public Property N_TestAritmatika() As String
        Get
            Return nilai_tesarimatika
        End Get
        Set(ByVal value As String)
            nilai_tesarimatika = value
        End Set
    End Property

    Public Property N_TestKpribadian() As String
        Get
            Return nilai_teskpribadian
        End Get
        Set(ByVal value As String)
            nilai_teskpribadian = value
        End Set
    End Property

    Public Property id_kdt() As String
        Get
            Return id_kandidat
        End Get
        Set(ByVal value As String)
            id_kandidat = value
        End Set
    End Property
End Class
