﻿Public Class Enthistori_hubkel
  

    Private id_kandidat As String
    Private nm_ayah As String
    Private nm_ibu As String
    Private nm_saudara1 As String
    Private nm_saudara2 As String
    Private nm_saudara3 As String
    Private usia_ayah As String
    Private usia_ibu As String
    Private usia_saudara1 As String
    Private usia_saudara2 As String
    Private usia_saudara3 As String
    Private pend_ayah As String
    Private pend_ibu As String
    Private pend_saudara1 As String
    Private pend_saudara2 As String
    Private pend_saudara3 As String
    Private pek_ayah As String
    Private pek_ibu As String
    Private pek_saudara1 As String
    Private pek_saudara2 As String
    Private pek_saudara3 As String

    Public Property IDKandidat() As String
        Get
            Return id_kandidat
        End Get
        Set(ByVal value As String)
            id_kandidat = value
        End Set
    End Property

    Public Property NamaAyah() As String
        Get
            Return nm_ayah
        End Get
        Set(ByVal value As String)
            nm_ayah = value
        End Set
    End Property

    Public Property NamaIbu() As String
        Get
            Return nm_ibu
        End Get
        Set(ByVal value As String)
            nm_ibu = value
        End Set
    End Property

    Public Property NamaSodara1() As String
        Get
            Return nm_saudara1
        End Get
        Set(ByVal value As String)
            nm_saudara1 = value
        End Set
    End Property

    Public Property NamaSodara2() As String
        Get
            Return nm_saudara2
        End Get
        Set(ByVal value As String)
            nm_saudara2 = value
        End Set
    End Property

    Public Property NamaSodara3() As String
        Get
            Return nm_saudara3
        End Get
        Set(ByVal value As String)
            nm_saudara3 = value
        End Set
    End Property

    Public Property UsiaAyah() As String
        Get
            Return usia_ayah
        End Get
        Set(ByVal value As String)
            usia_ayah = value
        End Set
    End Property

    Public Property UsiaIbu() As String
        Get
            Return usia_ibu
        End Get
        Set(ByVal value As String)
            usia_ibu = value
        End Set
    End Property

    Public Property UsiaSDR1() As String
        Get
            Return usia_saudara1
        End Get
        Set(ByVal value As String)
            usia_saudara1 = value
        End Set
    End Property

    Public Property UsiaSDR2() As String
        Get
            Return usia_saudara2
        End Get
        Set(ByVal value As String)
            usia_saudara2 = value
        End Set
    End Property

    Public Property UsiaSDR3() As String
        Get
            Return usia_saudara3
        End Get
        Set(ByVal value As String)
            usia_saudara3 = value
        End Set
    End Property

    Public Property PedidikanAyah() As String
        Get
            Return pend_ayah
        End Get
        Set(ByVal value As String)
            pend_ayah = value
        End Set
    End Property

    Public Property PendidikanIbu() As String
        Get
            Return pend_ibu
        End Get
        Set(ByVal value As String)
            pend_ibu = value
        End Set
    End Property

    Public Property PendidikanSDR1() As String
        Get
            Return pend_saudara1
        End Get
        Set(ByVal value As String)
            pend_saudara1 = value
        End Set
    End Property

    Public Property PendidikanSDR2() As String
        Get
            Return pend_saudara2
        End Get
        Set(ByVal value As String)
            pend_saudara2 = value
        End Set
    End Property

    Public Property PendidikanSDR3() As String
        Get
            Return pend_saudara3
        End Get
        Set(ByVal value As String)
            pend_saudara3 = value
        End Set
    End Property

    Public Property PekerjaanAyah() As String
        Get
            Return pek_ayah
        End Get
        Set(ByVal value As String)
            pek_ayah = value
        End Set
    End Property

    Public Property PekerjaanIbu() As String
        Get
            Return pek_ibu
        End Get
        Set(ByVal value As String)
            pek_ibu = value
        End Set
    End Property

    Public Property PekerjaanSDR1() As String
        Get
            Return pek_saudara1
        End Get
        Set(ByVal value As String)
            pek_saudara1 = value
        End Set
    End Property

    Public Property PekerjaanSDR2() As String
        Get
            Return pek_saudara2
        End Get
        Set(ByVal value As String)
            pek_saudara2 = value
        End Set
    End Property

    Public Property PekerjaanSDR3() As String
        Get
            Return pek_saudara3
        End Get
        Set(ByVal value As String)
            pek_saudara3 = value
        End Set
    End Property
End Class
