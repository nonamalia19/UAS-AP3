﻿Public Class CtrlSeleksi
    Dim result As Boolean
    Dim Modelseleksi As New Modelseleksi

    Public Function td(ByVal slk As EntSeleksi) As Boolean
     


        If slk.id_kdt.ToString() = "" Or slk.nm_kdt.ToString() = "" Or slk.jbt.ToString() = "" Or slk.div.ToString() = "" Or slk.pend.ToString() = "" Or slk.tg_kerja.ToString() = "" Or slk.N_TestA.ToString() = "" Or slk.N_TestKraeplin.ToString() = "" Or slk.N_TestAritmatika.ToString() = "" Or slk.N_TestKpribadian.ToString() = "" Or slk.id_use.ToString() = "" Then
            MsgBox("Data Belum Lengkap")
        Else
            result = Modelseleksi.create(slk)
            MsgBox("Data Telah Tersimpan")
        End If

        Return result
    End Function
    Public Function Setidlowongan() As String
        Return Modelseleksi.GetRunnKode()
        Return result
    End Function

    Public Function editdata(ByVal slk As EntSeleksi) As Boolean
        If slk.id_kdt = "" Or slk.nm_kdt = "" Or slk.jbt = "" Or slk.div = "" Or slk.pend = "" Or slk.tg_kerja = "" Or slk.N_TestA = "" Or slk.N_TestKraeplin = "" Or slk.N_TestAritmatika = "" Or slk.N_TestKpribadian = "" Or slk.id_use = "" Then
            MsgBox("Data Belum Lengkap")
        Else
            result = Modelseleksi.update(slk)
            MsgBox("Data Telah Terupdate")
        End If

        Return result
    End Function

    Public Function hapusdata(ByVal kode As String) As Boolean
        If kode = "" Then
            MsgBox("Silahkan Pilih Salah Satu Data Yang Akan Di Hapus")
        Else
            result = Modelseleksi.delete(kode)
            MsgBox("Data Telah Terhapus")
        End If

        Return result
    End Function

    Public Sub tampilkandt(ByVal DGV As DataGridView)
        Modelseleksi.ReadData(DGV)
    End Sub

    Public Sub SetComboIDKandidat(ByVal comboid As ComboBox)
        Modelseleksi.SetComboID(comboid)
    End Sub

    Public Sub Caridt(ByVal keyword As TextBox)
        Modelseleksi.filterData(keyword)
    End Sub

    Public Function cariDtByKode(ByVal kode As String) As EntSeleksi
        Dim slkLoc As New EntSeleksi
        slkLoc = Modelseleksi.findBykode(kode)

        Return slkLoc
    End Function
End Class
