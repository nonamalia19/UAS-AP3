﻿Public Class CtrlDaftar
    Dim result As Boolean
    Dim ModelDaftar As New ModelDaftar

    Public Function td(ByVal df As EntDaftar) As Boolean
        If df.id_low = "" Or df.nm_low = "" Or df.jbt = "" Or df.div = "" Or df.user = "" Or df.tg_kerja = "" Then
            MsgBox("Data Belum Lengkap")
        Else
            result = ModelDaftar.create(df)
            MsgBox("Data Telah Tersimpan")
        End If

        Return result
    End Function
    Public Function Setidlowongan() As String
        Return ModelDaftar.GetRunnKode()
        Return result
    End Function

    Public Function editdata(ByVal df As EntDaftar) As Boolean
        If df.id_low = "" Or df.nm_low = "" Or df.jbt = "" Or df.div = "" Or df.user = "" Or df.tg_kerja = "" Then
            MsgBox("Data Belum Lengkap")
        Else
            result = ModelDaftar.update(df)
            MsgBox("Data Telah Terupdate")
        End If

        Return result
    End Function

    Public Function hapusdata(ByVal kode As String) As Boolean
        If kode = "" Then
            MsgBox("Silahkan Pilih Salah Satu Data Yang Akan Di Hapus")
        Else
            result = ModelDaftar.delete(kode)
            MsgBox("Data Telah Terhapus")
        End If

        Return result
    End Function

    Public Sub tampilkandt(ByVal DGV As DataGridView)
        ModelDaftar.read(DGV)
    End Sub

    Public Sub Caridt(ByVal keyword As TextBox)
        ModelDaftar.filterData(keyword)
    End Sub

    Public Function cariDtByKode(ByVal kode As String) As EntDaftar
        Dim dfLoc As New EntDaftar
        dfLoc = ModelDaftar.findBykode(kode)

        Return dfLoc
    End Function
End Class
