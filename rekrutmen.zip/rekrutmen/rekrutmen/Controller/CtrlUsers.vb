﻿
Public Class CtrlUsers
    Dim model_user As New Modelusers
    Dim user As New EntUsers
    Dim result As Boolean

    Public Function editdata(ByVal usr As EntUsers) As Boolean
        If usr.idUser = "" Or usr.namaUser = "" Or usr.password = "" Or usr.username = "" Then
            MsgBox("Data belum lengkap")
        Else
            result = model_user.update(usr)
            MsgBox("Data telah terupdate")
        End If

        Return result
    End Function


    Public Function cariUser(ByVal username As String, ByVal password As String) As EntUsers
        user = model_user.cariUser(username, password)
        If user.idUser = "" Then
            MsgBox("user tidak ditemukan")

        End If

        Return user

    End Function

    Public Function cariDtByKode(ByVal kode As String) As EntUsers
        Dim divLoc As New EntUsers
        divLoc = model_user.findBykode(kode)

        Return divLoc
    End Function

    Public Function td(ByVal user As EntUsers) As Boolean
        If user.idUser = "" Or user.namaUser = "" Or user.password = "" Or user.username = "" Then
            MsgBox("Data Belum Lengkap")
        Else
            result = model_user.create(user)
            MsgBox("Data Telah Tersimpan")
        End If

        Return result
    End Function

    Public Function SetKodeUser() As String
        Return model_user.GetRunnKode()
        Return result
    End Function

    Public Function hapusdata(ByVal kode As String) As Boolean
        If kode = "" Then
            MsgBox("Silahkan pilih salah satu data yang akan di hapus")
        Else
            result = model_user.delete(kode)
            MsgBox("Data telah terhapus")
        End If

        Return result
    End Function

    Public Sub tampilkandt(ByVal DGV As DataGridView)
        model_user.read(DGV)
    End Sub

    Public Sub tampilDataAcces(ByVal DGV As DataGridView)
        model_user.readForAccess(DGV)
    End Sub

    Public Function EditDataAccess(ByVal kode As String, ByVal Flagcol As String, ByVal theValae As String) As Boolean
        If kode <> "" Or Flagcol <> "" Or theValae <> "" Then
            result = model_user.UpdateAccess(kode, Flagcol, theValae)
        End If
        Return result
    End Function

End Class

