﻿
Public Class CtrlDivisi
    Dim result As Boolean
    Dim ModelDivisi As New ModelDivisi

    Public Function td(ByVal div As Entdivisi) As Boolean
        If div.kddiv = "" Or div.nmdiv = "" Or div.jbt = "" Then
            MsgBox("Data Belum Lengkap")
        Else
            result = ModelDivisi.create(div)
            MsgBox("Data Telah Tersimpan")
        End If

        Return result
    End Function
    Public Function SetKodeDivisi() As String
        Return ModelDivisi.GetRunnKode()
        Return result
    End Function

    Public Function editdata(ByVal div As Entdivisi) As Boolean
        If div.kddiv = "" Or div.nmdiv = "" Or div.jbt = "" Then
            MsgBox("Data belum lengkap")
        Else
            result = ModelDivisi.update(div)
            MsgBox("Data telah terupdate")
        End If

        Return result
    End Function

    Public Function hapusdata(ByVal kode As String) As Boolean
        If kode = "" Then
            MsgBox("Silahkan pilih salah satu data yang akan di hapus")
        Else
            result = ModelDivisi.delete(kode)
            MsgBox("Data telah terhapus")
        End If

        Return result
    End Function

    Public Sub tampilkandt(ByVal DGV As DataGridView)
        ModelDivisi.read(DGV)
    End Sub

    Public Sub Caridt(ByVal keyword As TextBox)
        ModelDivisi.filterData(keyword)
    End Sub

    Public Function cariDtByKode(ByVal kode As String) As Entdivisi
        Dim divLoc As New Entdivisi
        divLoc = ModelDivisi.findBykode(kode)

        Return divLoc
    End Function

End Class
