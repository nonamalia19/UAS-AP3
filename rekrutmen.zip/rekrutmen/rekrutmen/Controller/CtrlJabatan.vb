﻿
Public Class CtrlJabatan
    Dim result As Boolean
    Dim ModelJabatan As New ModelJabatan
    Public Function td(ByVal jbt As Entjabatan) As Boolean
        If jbt.kdjbt = "" Or jbt.nmjbt = "" Then
            MsgBox("Data Belum Lengkap")
        Else
            result = ModelJabatan.create(jbt)
            MsgBox("Data Telah Tersimpan")
        End If

        Return result
    End Function

    Public Function editdata(ByVal jbt As Entjabatan) As Boolean
        If jbt.kdjbt = "" Or jbt.nmjbt = "" Then
            MsgBox("Data belum lengkap")
        Else
            result = ModelJabatan.update(jbt)
            MsgBox("Data telah terupdate")
        End If

        Return result
    End Function

    Public Function hapusdata(ByVal kode As String) As Boolean
        If kode = "" Then
            MsgBox("Kode Jabatan Harus DiIsi")
        Else
            result = ModelJabatan.delete(kode)
            MsgBox("Data telah terhapus")
        End If

        Return result
    End Function

    Public Sub tampilkandt(ByVal DGV As DataGridView)
        ModelJabatan.read(DGV)
    End Sub

    Public Sub Caridt(ByVal keyword As TextBox)
        ModelJabatan.filterData(keyword)
    End Sub

    Public Function cariDtByKode(ByVal kode As String) As Entjabatan
        Dim jbtLoc As New Entjabatan
        jbtLoc = ModelJabatan.findBykode(kode)

        Return jbtLoc
    End Function
End Class
