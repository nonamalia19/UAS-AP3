﻿Public Class CtrlHisKeluarga
    Dim result As Boolean
    Dim mdlHisKel As New ModelHisKeluarga

    Public Function TambahDataHistory(ByVal HisKel As Enthistory_keluarga) As Boolean

        result = mdlHisKel.CreateDataHisKeluarga(HisKel)
        Return result

    End Function

    Public Function editData(ByVal hisKEl As Enthistory_keluarga) As Boolean
        result = mdlHisKel.UpdateDataHisKeluarga(hisKEl)
        Return result
    End Function

    Public Function HapusData(ByVal kode As String) As Boolean
        result = mdlHisKel.Delete(kode)
        Return result
    End Function

    Public Function cariDataBykode(ByVal kode As String) As Enthistory_keluarga
        Dim kdtLoc As New Enthistory_keluarga
        kdtLoc = mdlHisKel.findBykode(kode)

        Return kdtLoc
    End Function

End Class
