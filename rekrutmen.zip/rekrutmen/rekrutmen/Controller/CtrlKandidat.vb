﻿Public Class CtrlKandidat
    Dim result As Boolean
    Dim model_kandidat As New ModelKandidat

    Public Function SetKodeKandidat() As String
        Return model_kandidat.GetRunnKode()
        Return result
    End Function
    Public Function TambahDataKandidat(ByVal kdt As EntKandidat) As Boolean
        If kdt.IDKandidat = "" Or kdt.NamaKandidat = "" Or kdt.TmpatLahir = "" Or kdt.TanggalLhr = "" Or kdt.AgamaKdt = "" Or kdt.PendidikanKdt = "" Or kdt.JenisKelamin = "" Or kdt.NoKtp = "" Or kdt.AlamatKandidat = "" Or kdt.NoTelp = "" Or kdt.NoRek = "" Or kdt.NoBpjs = "" Or kdt.NoNpwp = "" Or kdt.MassaKtp = "" Or kdt.TglMasuk = "" Or kdt.TenagaKerja = "" Or kdt.AreaPenempatan = "" Or kdt.KodeJabatan = "" Or kdt.KodeDivisi = "" Or kdt.IDKandidat = "" Then
            MsgBox("Data belum lengkap")
        Else
            result = model_kandidat.CreateDataKandidat(kdt)
            MsgBox("Data telah tersimpan")
        End If

        Return result

    End Function

    Public Function editData(ByVal kdt As EntKandidat) As Boolean
        If kdt.IDKandidat = "" Or kdt.NamaKandidat = "" Or kdt.TmpatLahir = "" Or kdt.TanggalLhr = "" Or kdt.AgamaKdt = "" Or kdt.PendidikanKdt = "" Or kdt.JenisKelamin = "" Or kdt.NoKtp = "" Or kdt.AlamatKandidat = "" Or kdt.NoTelp = "" Or kdt.NoRek = "" Or kdt.NoBpjs = "" Or kdt.NoNpwp = "" Or kdt.MassaKtp = "" Or kdt.TglMasuk = "" Or kdt.TenagaKerja = "" Or kdt.AreaPenempatan = "" Or kdt.KodeJabatan = "" Or kdt.KodeDivisi = "" Or kdt.IDKandidat = "" Then
            MsgBox("Data belum lengkap")
        Else
            result = model_kandidat.update(kdt)
            MsgBox("Data telah tersimpan")
        End If

        Return result
    End Function

    Public Function HapusData(ByVal kode As String) As Boolean
        If kode = "" Then
            MsgBox("Kode Kandidat Harus DiIsi")
        Else
            result = model_kandidat.Delete(kode)
            MsgBox("Data telah terhapus")
        End If

        Return result
    End Function
    Public Sub tampilkanData(ByVal DGV As DataGridView)
        model_kandidat.read(DGV)
    End Sub

    Public Sub cariData(ByVal keyword As TextBox)
        model_kandidat.filterData(keyword)
    End Sub

    Public Function cariDataBykode(ByVal kode As String) As EntKandidat
        Dim kdtLoc As New EntKandidat
        kdtLoc = model_kandidat.findBykode(kode)

        Return kdtLoc
    End Function

    Public Sub GetValueComboJabatan(ByVal obj As ComboBox)
        Try
            model_kandidat.ModelSetValueComboJabatan(obj)
        Catch ex As Exception
            MessageBox.Show(ex.ToString())
        End Try
    End Sub
    Public Sub GetValueComboDivisi(ByVal obj As ComboBox)
        Try
            model_kandidat.ModelSetValueComboDivisi(obj)
        Catch ex As Exception
            MessageBox.Show(ex.ToString())
        End Try
    End Sub
End Class
