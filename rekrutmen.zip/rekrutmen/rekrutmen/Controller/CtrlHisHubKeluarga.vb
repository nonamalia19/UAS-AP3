﻿Public Class CtrlHisHubKeluarga
    Dim result As Boolean
    Dim mdlHisKel As New ModelHisHubunganKel

    Public Function TambahDataHistoryHubkel(ByVal HisKel As Enthistori_hubkel) As Boolean

        result = mdlHisKel.CreateDataHisHubunganKEl(HisKel)
        Return result

    End Function

    Public Function editData(ByVal hisKEl As Enthistori_hubkel) As Boolean
        result = mdlHisKel.UpdateDataHisHubKeluarga(hisKEl)
        Return result
    End Function

    Public Function HapusData(ByVal kode As String) As Boolean
        result = mdlHisKel.Delete(kode)
        Return result
    End Function

    Public Function cariDataBykode(ByVal kode As String) As Enthistori_hubkel
        Dim kdtLoc As New Enthistori_hubkel
        kdtLoc = mdlHisKel.findBykode(kode)

        Return kdtLoc
    End Function

End Class
