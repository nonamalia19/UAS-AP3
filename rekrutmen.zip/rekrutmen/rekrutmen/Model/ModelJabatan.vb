﻿Imports System.Data.SqlClient
Public Class ModelJabatan
    Dim jbt As New Entjabatan
    Dim q As String
    Dim dt As New DataTable
    Dim bs As New BindingSource
    Dim dbConn As New ConnectionSQL

    Public Function create(ByVal jbt As Entjabatan) As Boolean
        q = "insert into jabatan (kd_jabatan, nm_jabatan) "
        q += "values('{0}', '{1}')"
        q = String.Format(q, jbt.kdjbt, jbt.nmjbt)

        Return dbConn.jalankanQuery(q)
    End Function
    Public Function update(ByVal jbt As Entjabatan) As Boolean
        q = "update jabatan  set nm_jabatan = '{0}'"
        q += "where kd_jabatan = '{1}'"
        q = String.Format(q, jbt.nmjbt, jbt.kdjbt)

        Return dbConn.jalankanQuery(q)
    End Function

    Public Function delete(ByVal kode As String) As Boolean
        q = "delete from jabatan where kd_jabatan = '{0}'"
        q = String.Format(q, kode)

        Return dbConn.jalankanQuery(q)
    End Function

    Public Function findBykode(ByVal kode As String) As Entjabatan
        If kode <> "" Then
            q = "select * from jabatan where kd_jabatan = '{0}'"
            q = String.Format(q, kode)
            dt = dbConn.bukaTable(q)
            jbt.kdjbt = dt.Rows(0)(0).ToString
            jbt.nmjbt = dt.Rows(0)(1).ToString

        End If
        Return jbt
    End Function

    Public Sub read(ByVal grid As DataGridView)
        q = "select T0.Kd_jabatan as [ Kode Jabatan ], t0.Nm_jabatan as [ Nama Jabatan ] from jabatan t0"
        dt = dbConn.bukaTable(q)
        grid.DataSource = dt
        bs.DataSource = dt
    End Sub

    Public Sub filterData(ByVal keyword As TextBox)
        bs.Filter = "nm_jabatan like '%" + keyword.Text + "%'"
    End Sub


End Class
