﻿Public Class ModelKandidat
    Dim kdt As New EntKandidat
    Dim QueryKandidat As String
    Dim dt As New DataTable
    Dim bs As New BindingSource
    Dim dbConn As New ConnectionSQL

    Public Function GetRunnKode() As String
        QueryKandidat = "Select Isnull(Convert(int,Max(Right(id_kandidat,3))),0)  from Kandidat"
        dt = dbConn.bukaTable(QueryKandidat)
        kdt.KodeDivisi = "KND" + (CInt(dt.Rows(0)(0)) + 1).ToString
        Return kdt.KodeDivisi.ToString()
    End Function

    Public Function CreateDataKandidat(ByVal kdt As EntKandidat) As Boolean
        QueryKandidat = "insert into kandidat(id_kandidat , nm_kandidat, tmp_lhr, tgl_lhr, agama, pendidikan, j_kelamin, no_ktp, alamat, no_tlp, no_rek, no_bpjstk, no_npwp, masaberlaku_ktp,tgl_masuk, tenaga_kerja, area_penempatan, kd_jabatan, kd_divisi,status_pernikahan,status_kandidat,doc_date) "
        QueryKandidat += "values('{0}', '{1}', '{2}', '{3}', '{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}','{12}','{13}','{14}','{15}','{16}','{17}','{18}','{19}','{20}',{21})"
        QueryKandidat = String.Format(QueryKandidat, kdt.IDKandidat, kdt.NamaKandidat, kdt.TmpatLahir, kdt.TanggalLhr, kdt.AgamaKdt, kdt.PendidikanKdt, kdt.JenisKelamin, kdt.NoKtp, kdt.AlamatKandidat, kdt.NoTelp, kdt.NoRek, kdt.NoBpjs, kdt.NoNpwp, kdt.MassaKtp, kdt.TglMasuk, kdt.TenagaKerja, kdt.AreaPenempatan, kdt.KodeJabatan, kdt.KodeDivisi, kdt.StatusKawin, kdt.StatusKandidat, "GetDate()")
        Return dbConn.jalankanQuery(QueryKandidat)
    End Function

    Public Function Update(ByVal kdt As EntKandidat) As Boolean
        QueryKandidat = "update kandidat set  nm_kandidat = '{0}', "
        QueryKandidat += "tmp_lhr = '{1}', "
        QueryKandidat += "tgl_lhr = '{2}', "
        QueryKandidat += "agama = '{3}', "
        QueryKandidat += "pendidikan = '{4}', "
        QueryKandidat += "j_kelamin = '{5}', "
        QueryKandidat += "no_ktp = '{6}', "
        QueryKandidat += "alamat = '{7}', "
        QueryKandidat += "no_tlp = '{8}', "
        QueryKandidat += "no_rek = '{9}', "
        QueryKandidat += "no_bpjstk = '{10}', "
        QueryKandidat += "no_npwp = '{11}', "
        QueryKandidat += "masaberlaku_ktp = '{12}', "
        QueryKandidat += "tgl_masuk = '{13}', "
        QueryKandidat += "tenaga_kerja = '{14}', "
        QueryKandidat += "area_penempatan = '{15}', "
        QueryKandidat += "kd_jabatan = '{16}', "
        QueryKandidat += "kd_divisi = '{17}',"
        QueryKandidat += "[status_kandidat] = '{18}', "
        QueryKandidat += "[status_pernikahan] = '{19}' "
        QueryKandidat += "where id_kandidat = '{20}'"

        QueryKandidat = String.Format(QueryKandidat.Trim(), kdt.NamaKandidat.Trim(), kdt.TmpatLahir.Trim(), kdt.TanggalLhr.Trim(), kdt.AgamaKdt.Trim(), kdt.PendidikanKdt.Trim(), kdt.JenisKelamin.Trim(), kdt.NoKtp.Trim(), kdt.AlamatKandidat.Trim(), kdt.NoTelp.Trim(), kdt.NoRek.Trim(), kdt.NoBpjs.Trim(), kdt.NoNpwp.Trim(), kdt.MassaKtp.Trim(), kdt.TglMasuk.Trim(), kdt.TenagaKerja.Trim(), kdt.AreaPenempatan.Trim(), kdt.KodeJabatan.Trim(), kdt.KodeDivisi.Trim(), kdt.StatusKandidat.Trim(), kdt.StatusKawin.Trim(), kdt.IDKandidat.Trim())
        Return dbConn.jalankanQuery(QueryKandidat)
    End Function

    Public Function Delete(ByVal kode As String) As Boolean
        QueryKandidat = "delete from kandidat where id_kandidat = '{0}'"
        QueryKandidat = String.Format(QueryKandidat, kode)

        Return dbConn.jalankanQuery(QueryKandidat)
    End Function

    Public Function findBykode(ByVal kode As String) As EntKandidat
        If kode <> "" Then
            QueryKandidat = "select * from kandidat T0 left join histori_keluarga T1 on T0.id_kandidat=T1.id_kandidat where T0.id_kandidat = '{0}'"
            QueryKandidat = String.Format(QueryKandidat, kode)
            Try
                dt = dbConn.bukaTable(QueryKandidat)
            Catch ex As Exception
                MessageBox.Show(ex.ToString())
            End Try

            kdt.IDKandidat = dt.Rows(0)(0).ToString
            kdt.NamaKandidat = dt.Rows(0)(1).ToString
            kdt.TmpatLahir = dt.Rows(0)(2).ToString
            kdt.TanggalLhr = dt.Rows(0)(3).ToString
            kdt.AgamaKdt = dt.Rows(0)(4).ToString
            kdt.PendidikanKdt = dt.Rows(0)(5).ToString
            kdt.JenisKelamin = dt.Rows(0)(6).ToString
            kdt.NoKtp = dt.Rows(0)(7).ToString
            kdt.AlamatKandidat = dt.Rows(0)(8).ToString
            kdt.NoTelp = dt.Rows(0)(9).ToString
            kdt.NoRek = dt.Rows(0)(10).ToString
            kdt.NoBpjs = dt.Rows(0)(11).ToString
            kdt.NoNpwp = dt.Rows(0)(12).ToString
            kdt.MassaKtp = dt.Rows(0)(13).ToString
            kdt.TglMasuk = dt.Rows(0)(14).ToString
            kdt.TenagaKerja = dt.Rows(0)(15).ToString
            kdt.AreaPenempatan = dt.Rows(0)(16).ToString
            kdt.KodeJabatan = dt.Rows(0)(17).ToString
            kdt.KodeDivisi = dt.Rows(0)(18).ToString
            kdt.StatusKandidat = dt.Rows(0)(19).ToString
            kdt.StatusKawin = dt.Rows(0)(21).ToString()


        End If

        Return kdt
    End Function

    Public Sub read(ByVal grid As DataGridView)
        QueryKandidat = "select t0.id_kandidat as [ ID Kandidat ], t0.nm_kandidat as [ Nama Kandidat ], t0.tmp_lhr as [ Tempat Lahir ], t0.tgl_lhr as [ Tanggal Lahir ], t0.agama as [ Agama ], t0.pendidikan as [ Pendidikan ], t0.j_kelamin as [ Jenis Kelamin ], t0.no_ktp as [ Nomor KTP ], t0.alamat as [ Alamat ], t0.no_tlp as [ Nomor Telepon ], t0.no_rek as [ Nomor Rekening ], t0.no_bpjstk as [ Nomor BPJS TK ],t0.no_npwp as [ Nomor NPWP ], t0.masaberlaku_ktp as [ Masa Berlaku KTP ], t0.tgl_masuk as [ Tanggal Masuk ], t0.tenaga_kerja as [ Tenaga Kerja ], t0.area_penempatan as [ Area Penempatan ], t0.kd_jabatan as [ Kode Jabatan ], t0.kd_divisi as [ Kode Divisi ], t0.status_kandidat as [ Status Kandidat ], t0.id_lowongan as [ ID Lowongan ], t0.Status_Pernikahan as [ Status Pernikahan ],t0.Doc_date As [Tanggal Dokumen] from Kandidat t0"
        dt = dbConn.bukaTable(QueryKandidat)
        grid.DataSource = dt
        bs.DataSource = dt
    End Sub
    Public Function TabelLayout(ByVal kode As String) As DataTable
        QueryKandidat = "Exec LAYOUTKNDT '" & kode & "' "
        dt = dbConn.bukaTable(QueryKandidat)
        Return dt
    End Function

    Public Function TabelReportkand(ByVal parameterMonth As String) As DataTable
        QueryKandidat = "Select * From Kandidat Where Month(doc_date)=MONTH('" & parameterMonth & "')"
        dt = dbConn.bukaTable(QueryKandidat)
        Return dt
    End Function
 

    Public Sub ModelSetValueComboJabatan(ByVal obj As ComboBox)
        QueryKandidat = "select Kd_Jabatan from Jabatan"
        dt = dbConn.bukaTable(QueryKandidat)
        For i As Integer = 0 To dt.Rows.Count - 1
            obj.Items.Add(dt.Rows(i).ItemArray(0).ToString().Trim())
        Next
    End Sub
    Public Sub ModelSetValueComboDivisi(ByVal obj As ComboBox)
        QueryKandidat = "select Kd_Divisi from Divisi"
        dt = dbConn.bukaTable(QueryKandidat)
        For i As Integer = 0 To dt.Rows.Count - 1
            obj.Items.Add(dt.Rows(i).ItemArray(0).ToString().Trim())
        Next
    End Sub

    Public Sub filterData(ByVal keyword As TextBox)
        bs.Filter = "nm_kandidat like '%" + keyword.Text + "%'"
    End Sub
End Class
