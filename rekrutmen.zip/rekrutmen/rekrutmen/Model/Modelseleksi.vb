﻿Public Class Modelseleksi
    Dim slk As New EntSeleksi
    Dim q As String
    Dim dt As New DataTable
    Dim bs As New BindingSource
    Dim dbConn As New ConnectionSQL

    Public Function create(ByVal slk As EntSeleksi) As Boolean
        q = "insert into seleksi (id_kandidat, nm_kandidat, jabatan, divisi, pendidikan, tenaga_kerja, nilai_tesA, nilai_teskraeplin, nilai_tesaritmatika, nilai_teskpribadian, id_user) "
        q += "values('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}')"
        q = String.Format(q, slk.id_kdt, slk.nm_kdt, slk.jbt, slk.div, slk.pend, slk.tg_kerja, slk.N_TestA, slk.N_TestKraeplin, slk.N_TestAritmatika, slk.N_TestKpribadian, slk.id_use)
        Return dbConn.jalankanQuery(q)
    End Function

    Public Function GetRunnKode() As String
        q = "Select Isnull(Convert(int,Max(Right(id_kandidat,10))),0)  from seleksi"
        dt = dbConn.bukaTable(q)
        slk.id_kdt = "DVS" + (CInt(dt.Rows(0)(0)) + 1).ToString
        Return slk.id_kdt.ToString()
    End Function
    Public Function update(ByVal slk As EntSeleksi) As Boolean
        q = "update seleksi  set nm_kandidat = '{0}', "
        q += "jabatan = '{1}', "
        q += "divisi = '{2}' ,"
        q += "pendidikan = '{3}' ,"
        q += "tenaga_kerja = '{4}' ,"
        q += "nilai_tesA = '{5}', "
        q += "nilai_teskraeplin = '{6}' ,"
        q += "nilai_tesaritmatika = '{7}', "
        q += "nilai_teskpribadian = '{8}', "
        q += "id_user = '{9}' "
        q += "where id_kandidat = '{10}'"
        q = String.Format(q, slk.nm_kdt, slk.jbt, slk.div, slk.pend, slk.tg_kerja, slk.N_TestA, slk.N_TestKraeplin, slk.N_TestAritmatika, slk.N_TestKpribadian, slk.id_use, slk.id_kdt)

        Return dbConn.jalankanQuery(q)
    End Function

    Public Function delete(ByVal kode As String) As Boolean
        q = "delete from seleksi where id_kandidat = '{0}'"
        q = String.Format(q, kode)

        Return dbConn.jalankanQuery(q)
    End Function

    Public Function findBykode(ByVal kode As String) As EntSeleksi
        If kode <> "" Then
            q = "select * from seleksi where id_kandidat = '{0}'"
            q = String.Format(q, kode)
            dt = dbConn.bukaTable(q)
            slk.id_kdt = dt.Rows(0)(0).ToString
            slk.nm_kdt = dt.Rows(0)(1).ToString
            slk.jbt = dt.Rows(0)(2).ToString
            slk.div = dt.Rows(0)(3).ToString
            slk.pend = dt.Rows(0)(4).ToString
            slk.tg_kerja = dt.Rows(0)(5).ToString
            slk.N_TestA = dt.Rows(0)(6).ToString
            slk.N_TestKraeplin = dt.Rows(0)(7).ToString
            slk.N_TestAritmatika = dt.Rows(0)(8).ToString
            slk.N_TestKpribadian = dt.Rows(0)(9).ToString
            slk.id_use = dt.Rows(0)(10).ToString

        End If

        Return slk
    End Function

    Public Sub ReadData(ByVal grid As DataGridView)
        q = "Select T0.id_kandidat As [ID Kandidat],T0.nm_kandidat As [Nama Kandidat],T0.Jabatan,T0.Divisi,T0.Pendidikan,T0.tenaga_kerja As [Tenaga Kerja],T0.nilai_tesA As [Nilai Test A],T0.nilai_teskraeplin As [Nilai Kraeplin],T0.nilai_tesaritmatika As [Nilai Test Aritmatika],T0.nilai_teskpribadian As [Nilai Test Kepribadian],T0.id_user As [ID User] From Seleksi T0"
        dt = dbConn.bukaTable(q)
        grid.DataSource = dt
        bs.DataSource = dt
    End Sub

    Public Sub SetComboID(ByVal combo As ComboBox)
        q = "Select Id_Kandidat From Kandidat Where id_kandidat not in (select Id_Kandidat from Seleksi)"
        dt = dbConn.bukaTable(q)
        For i As Integer = 0 To dt.Rows.Count - 1
            combo.Items.Add(dt.Rows(i)(0).ToString)
        Next
       
    End Sub

    Public Sub filterData(ByVal keyword As TextBox)
        bs.Filter = "nm_kandidat like '%" + keyword.Text + "%'"
    End Sub

    Public Function TabelLayoutSeleksi(ByVal kode As String) As DataTable
        Dim QueryKandidat As String = "Exec LAYOUTSelek '" & kode & "' "
        dt = dbConn.bukaTable(QueryKandidat)
        Return dt
    End Function

    Public Function TabelWhenIDSelected(ByVal kode As String) As DataTable
        Dim QueryKandidat As String = "select * From Kandidat Where id_kandidat='" & kode & "' "
        dt = dbConn.bukaTable(QueryKandidat)
        Return dt
    End Function
End Class
