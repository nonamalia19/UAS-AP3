﻿Public Class ModelDaftar
    Dim df As New EntDaftar
    Dim q As String
    Dim dt As New DataTable
    Dim bs As New BindingSource
    Dim dbConn As New ConnectionSQL

    Public Function create(ByVal df As EntDaftar) As Boolean
        q = "insert into daftar_lowongan (id_lowongan, nm_lowongan, jabatan, divisi, users, tenaga_kerja) "
        q += "values('{0}', '{1}', '{2}', '{3}', '{4}', '{5}')"
        q = String.Format(q, df.id_low, df.nm_low, df.jbt, df.div, df.user, df.tg_kerja)
        Return dbConn.jalankanQuery(q)
    End Function

    Public Function GetRunnKode() As String
        q = "Select Isnull(Convert(int,Max(id_lowongan)),0)  from daftar_lowongan"
        dt = dbConn.bukaTable(q)
        df.id_low = (CInt(dt.Rows(0)(0)) + 1).ToString
        Return df.id_low.ToString()
    End Function
    Public Function update(ByVal df As EntDaftar) As Boolean
        q = "update daftar_lowongan  set nm_lowongan = '{0}', "
        q += "jabatan = '{1}', "
        q += "divisi = '{2}', "
        q += "users = '{3}' ,"
        q += "tenaga_kerja = '{4}' "
        q += "where id_lowongan = '{5}'"
        q = String.Format(q, df.nm_low, df.jbt, df.div, df.user, df.tg_kerja, df.id_low)

        Return dbConn.jalankanQuery(q)
    End Function

    Public Function delete(ByVal kode As String) As Boolean
        q = "delete from daftar_lowongan where id_lowongan = '{0}'"
        q = String.Format(q, kode)

        Return dbConn.jalankanQuery(q)
    End Function

    Public Function findBykode(ByVal kode As String) As EntDaftar
        If kode <> "" Then
            q = "select * from daftar_lowongan where id_lowongan = '{0}'"
            q = String.Format(q, kode)
            dt = dbConn.bukaTable(q)
            df.id_low = dt.Rows(0)(0).ToString
            df.nm_low = dt.Rows(0)(1).ToString
            df.jbt = dt.Rows(0)(2).ToString
            df.div = dt.Rows(0)(3).ToString
            df.user = dt.Rows(0)(4).ToString
            df.tg_kerja = dt.Rows(0)(4).ToString
        End If

        Return df
    End Function

    Public Sub read(ByVal grid As DataGridView)
        q = "select * from daftar_lowongan"
        dt = dbConn.bukaTable(q)
        grid.DataSource = dt
        bs.DataSource = dt
    End Sub

    Public Sub filterData(ByVal keyword As TextBox)
        bs.Filter = "nm_lowongan like '%" + keyword.Text + "%'"
    End Sub
End Class
