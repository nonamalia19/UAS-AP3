﻿Public Class Modelusers
    Dim dbConn As New ConnectionSQL ' koneksi database
    Dim q As String ' string sql
    Dim dt As New DataTable 'data table
    Dim user As New EntUsers ' entity users
    Dim bs As New BindingSource

    Public Sub read(ByVal grid As DataGridView)
        q = "select t0.id_user as [ ID User ], t0.nm_user as [ Nama User ], t0.pass as [ Password ], t0.UserName from users t0"
        dt = dbConn.bukaTable(q)
        grid.DataSource = dt
        bs.DataSource = dt
    End Sub

    Public Function cariUser(ByVal username As String, ByVal password As String) As EntUsers
        q = "select * from users where username = '{0}' and pass = '{1}'"
        q = (String.Format(q, username, password))
        dt = dbConn.bukaTable(q)
        If dt.Rows.Count <> 0 Then
            user.idUser = dt.Rows(0)(0).ToString
            user.namaUser = dt.Rows(0)(1).ToString
            user.username = dt.Rows(0)(3).ToString
            user.password = dt.Rows(0)(2).ToString
            'Trus di set disini
            MenuKandidat = dt.Rows(0)(4).ToString
            MenuSeleksi = dt.Rows(0)(5).ToString
            MenuDivisi = dt.Rows(0)(6).ToString
            MenuJabatan = dt.Rows(0)(7).ToString
            MenuUsers = dt.Rows(0)(8).ToString
            MenuLowongan = dt.Rows(0)(9).ToString
            MenuUtility = dt.Rows(0)(10).ToString
        End If

        Return user

    End Function


    Public Function create(ByVal entusr As EntUsers) As Boolean
        q = "insert into users (id_user, nm_user, pass, username)"
        q += "values('{0}', '{1}', '{2}','{3}')"
        q = String.Format(q, entusr.idUser, entusr.namaUser, entusr.password, entusr.username)
        Return dbConn.jalankanQuery(q)
    End Function

    Public Function GetRunnKode() As String
        q = "Select Isnull(Convert(int,Max(Right(id_user,3))),0) from users"
        dt = dbConn.bukaTable(q)
        user.idUser = "USR" + (CInt(dt.Rows(0)(0)) + 1).ToString
        Return user.idUser.ToString()
    End Function

    Public Function update(ByVal div As EntUsers) As Boolean
        ', , username
        q = "update users  set nm_user = '{0}', "
        q += "pass = '{1}',"
        q += "username='{2}'"
        q += "where id_user = '{3}'"
        q = String.Format(q, div.namaUser, div.password, div.username, div.idUser)

        Return dbConn.jalankanQuery(q)
    End Function

    Public Function delete(ByVal kode As String) As Boolean
        q = "delete from users where id_user = '{0}'"
        q = String.Format(q, kode)

        Return dbConn.jalankanQuery(q)
    End Function

    Public Function findBykode(ByVal kode As String) As EntUsers
        If kode <> "" Then
            q = "select * from users where id_user = '{0}'"
            q = String.Format(q, kode)
            dt = dbConn.bukaTable(q)
            user.idUser = dt.Rows(0)(0).ToString
            user.namaUser = dt.Rows(0)(1).ToString
            user.password = dt.Rows(0)(2).ToString
            user.username = dt.Rows(0)(3).ToString
        End If

        Return user
    End Function
    'ini juga funcsi baru
    Public Function UpdateAccess(ByVal kode As String, ByVal FlagCol As Integer, ByVal theValue As String) As Boolean
        Dim Mycolumn As String = ""
        If FlagCol = 2 Then
            Mycolumn = "Kandidat"
        ElseIf FlagCol = 3 Then
            Mycolumn = "Seleksi"
        ElseIf FlagCol = 4 Then
            Mycolumn = "Divisi"
        ElseIf FlagCol = 5 Then
            Mycolumn = "Jabatan"
        ElseIf FlagCol = 6 Then
            Mycolumn = "Users"
        ElseIf FlagCol = 7 Then
            Mycolumn = "Lowongan"
        ElseIf FlagCol = 8 Then
            Mycolumn = "Utility"
        End If
        q = "update users  set " & Mycolumn & " = '{0}' "
        q += "where id_user = '{1}'"
        q = String.Format(q, theValue, kode)
        Return dbConn.jalankanQuery(q)
    End Function

    Public Sub readForAccess(ByVal grid As DataGridView)
        q = "select t0.id_user as [ ID User ], t0.nm_user as [ Nama User ],T0.Kandidat,T0.Seleksi,T0.Divisi,T0.Jabatan,T0.Users,T0.Lowongan,T0.Utility from users T0"
        dt = dbConn.bukaTable(q)
        grid.DataSource = dt
        bs.DataSource = dt
    End Sub
End Class


