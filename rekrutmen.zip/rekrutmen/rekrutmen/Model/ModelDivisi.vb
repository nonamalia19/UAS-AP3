﻿
Public Class ModelDivisi
    Dim div As New Entdivisi
    Dim q As String
    Dim dt As New DataTable
    Dim bs As New BindingSource
    Dim dbConn As New ConnectionSQL

    Public Function create(ByVal div As Entdivisi) As Boolean
        q = "insert into divisi (kd_divisi, nm_divisi, jabatan) "
        q += "values('{0}', '{1}', '{2}')"
        q = String.Format(q, div.kddiv, div.nmdiv, div.jbt)
        Return dbConn.jalankanQuery(q)
    End Function

    Public Function GetRunnKode() As String
        q = "Select Isnull(Convert(int,Max(Right(kd_divisi,3))),0)  from divisi"
        dt = dbConn.bukaTable(q)
        div.kddiv = "DVS" + (CInt(dt.Rows(0)(0)) + 1).ToString
        Return div.kddiv.ToString()
    End Function
    Public Function update(ByVal div As Entdivisi) As Boolean
        q = "update divisi  set nm_divisi = '{0}', "
        q += "jabatan = '{1}' "
        q += "where kd_divisi = '{2}'"
        q = String.Format(q, div.nmdiv, div.jbt, div.kddiv)

        Return dbConn.jalankanQuery(q)
    End Function

    Public Function delete(ByVal kode As String) As Boolean
        q = "delete from divisi where kd_divisi = '{0}'"
        q = String.Format(q, kode)

        Return dbConn.jalankanQuery(q)
    End Function

    Public Function findBykode(ByVal kode As String) As Entdivisi
        If kode <> "" Then
            q = "select * from divisi where kd_divisi = '{0}'"
            q = String.Format(q, kode)
            dt = dbConn.bukaTable(q)
            div.kddiv = dt.Rows(0)(0).ToString
            div.nmdiv = dt.Rows(0)(1).ToString
            div.jbt = dt.Rows(0)(2).ToString
        End If

        Return div
    End Function

    Public Sub read(ByVal grid As DataGridView)
        q = "Select T0.kd_divisi As [Kode Divisi],T0.nm_divisi As [Nama Divisi],T0.Jabatan From divisi T0"
        dt = dbConn.bukaTable(q)
        grid.DataSource = dt
        bs.DataSource = dt
    End Sub

    Public Sub filterData(ByVal keyword As TextBox)
        bs.Filter = "nm_divisi like '%" + keyword.Text + "%'"
    End Sub

End Class
