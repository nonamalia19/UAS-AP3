﻿Public Class ModelHisHubunganKel
    Dim hisHubKel As New Enthistori_hubkel
    Dim QueryKandidat As String
    Dim dt As New DataTable
    Dim bs As New BindingSource
    Dim dbConn As New ConnectionSQL
    Public Function CreateDataHisHubunganKEl(ByVal hiskel As Enthistori_hubkel) As Boolean
        QueryKandidat = "insert into [histori_hubkel] (id_kandidat,nm_ayah, nm_ibu, nm_saudara1, nm_saudara2, nm_saudara3, usia_ayah, usia_ibu, usia_saudara1, usia_saudara2, usia_saudara3, pend_ayah, pend_ibu,  pend_saudara1, pend_saudara2, pend_saudara3, pek_ayah, pek_ibu, pek_saudara1, pek_saudara2, pek_saudara3)"
        QueryKandidat += "values('{0}', '{1}', '{2}', '{3}', '{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}','{12}','{13}','{14}','{15}','{16}','{17}','{18}','{19}','{20}')"
        QueryKandidat = String.Format(QueryKandidat, hiskel.IDKandidat, hiskel.NamaAyah, hiskel.NamaIbu, hiskel.NamaSodara1, hiskel.NamaSodara2, hiskel.NamaSodara3, hiskel.UsiaAyah, hiskel.UsiaIbu, hiskel.UsiaSDR1, hiskel.UsiaSDR2, hiskel.UsiaSDR3, hiskel.PekerjaanAyah, hiskel.PendidikanIbu, hiskel.PendidikanSDR1, hiskel.PendidikanSDR2, hiskel.PendidikanSDR3, hiskel.PekerjaanAyah, hiskel.PekerjaanIbu, hiskel.PekerjaanSDR1, hiskel.PekerjaanSDR2, hiskel.PekerjaanSDR3)
        Return dbConn.jalankanQuery(QueryKandidat)
    End Function

    Public Function UpdateDataHisHubKeluarga(ByVal hiskel As Enthistori_hubkel) As Boolean
        ' , , , pek_saudara2, pek_saudara3, id_kandidat

        QueryKandidat = "update [histori_hubkel] set  nm_ayah = '{0}', "
        QueryKandidat += "nm_ibu = '{1}', "
        QueryKandidat += "nm_saudara1 = '{2}', "
        QueryKandidat += "nm_saudara2 = '{3}', "
        QueryKandidat += "nm_saudara3 = '{4}', "
        QueryKandidat += "usia_ayah = '{5}', "
        QueryKandidat += "usia_ibu = '{6}', "
        QueryKandidat += "usia_saudara1 = '{7}', "
        QueryKandidat += "usia_saudara2 = '{8}', "
        QueryKandidat += "usia_saudara3 = '{9}', "
        QueryKandidat += "pend_ayah = '{10}', "
        QueryKandidat += "pend_ibu = '{11}', "
        QueryKandidat += "pend_saudara1 = '{12}', "
        QueryKandidat += "pend_saudara2 = '{13}', "
        QueryKandidat += "pend_saudara3 = '{14}', "
        QueryKandidat += "pek_ayah = '{15}',"
        QueryKandidat += "pek_ibu = '{16}', "
        QueryKandidat += "pek_saudara1 = '{17}', "
        QueryKandidat += "pek_saudara2 = '{18}', "
        QueryKandidat += "pek_saudara3 = '{19}'"
        QueryKandidat += "where id_kandidat = '{20}'"
        QueryKandidat = String.Format(QueryKandidat, hiskel.NamaAyah, hiskel.NamaIbu, hiskel.NamaSodara1, hiskel.NamaSodara2, hiskel.NamaSodara3, hiskel.UsiaAyah, hiskel.UsiaIbu, hiskel.UsiaSDR1, hiskel.UsiaSDR2, hiskel.UsiaSDR3, hiskel.PekerjaanAyah, hiskel.PendidikanIbu, hiskel.PendidikanSDR1, hiskel.PendidikanSDR2, hiskel.PendidikanSDR3, hiskel.PekerjaanAyah, hiskel.PekerjaanIbu, hiskel.PekerjaanSDR1, hiskel.PekerjaanSDR2, hiskel.PekerjaanSDR3, hiskel.IDKandidat)
        Return dbConn.jalankanQuery(QueryKandidat)
    End Function

    Public Function Delete(ByVal kode As String) As Boolean
        QueryKandidat = "delete from [histori_hubkel] where id_kandidat = '{0}'"
        QueryKandidat = String.Format(QueryKandidat, kode)
        Return dbConn.jalankanQuery(QueryKandidat)
    End Function

    Public Function findBykode(ByVal kode As String) As Enthistori_hubkel
        If kode <> "" Then
            QueryKandidat = "select * from histori_hubkel  where id_kandidat = '{0}'"
            QueryKandidat = String.Format(QueryKandidat, kode)
            Try
                dt = dbConn.bukaTable(QueryKandidat)
            Catch ex As Exception
                MessageBox.Show(ex.ToString())
            End Try

            hisHubKel.NamaAyah = dt.Rows(0)(0).ToString().Trim()
            hisHubKel.NamaIbu = dt.Rows(0)(1).ToString().Trim()
            hisHubKel.NamaSodara1 = dt.Rows(0)(2).ToString().Trim()
            hisHubKel.NamaSodara2 = dt.Rows(0)(3).ToString().Trim()
            hisHubKel.NamaSodara3 = dt.Rows(0)(4).ToString().Trim()
            hisHubKel.UsiaAyah = dt.Rows(0)(5).ToString().Trim()
            hisHubKel.UsiaIbu = dt.Rows(0)(6).ToString().Trim()
            hisHubKel.UsiaSDR1 = dt.Rows(0)(7).ToString().Trim()
            hisHubKel.UsiaSDR2 = dt.Rows(0)(8).ToString().Trim()
            hisHubKel.UsiaSDR3 = dt.Rows(0)(9).ToString().Trim()
            hisHubKel.PedidikanAyah = dt.Rows(0)(10).ToString().Trim()
            hisHubKel.PendidikanIbu = dt.Rows(0)(11).ToString().Trim()
            hisHubKel.PendidikanSDR1 = dt.Rows(0)(12).ToString().Trim()
            hisHubKel.PendidikanSDR2 = dt.Rows(0)(13).ToString().Trim()
            hisHubKel.PendidikanSDR3 = dt.Rows(0)(14).ToString().Trim()
            hisHubKel.PekerjaanAyah = dt.Rows(0)(15).ToString().Trim()
            hisHubKel.PekerjaanIbu = dt.Rows(0)(16).ToString().Trim()
            hisHubKel.PekerjaanSDR1 = dt.Rows(0)(17).ToString().Trim()
            hisHubKel.PekerjaanSDR2 = dt.Rows(0)(18).ToString().Trim()
            hisHubKel.PekerjaanSDR3 = dt.Rows(0)(19).ToString().Trim()
            hisHubKel.IDKandidat = dt.Rows(0)(20).ToString().Trim()
        End If

        Return hisHubKel
    End Function

End Class
