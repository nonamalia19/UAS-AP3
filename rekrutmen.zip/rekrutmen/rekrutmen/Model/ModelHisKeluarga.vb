﻿Public Class ModelHisKeluarga
    Dim hisKel As New Enthistory_keluarga
    Dim QueryKandidat As String
    Dim dt As New DataTable
    Dim bs As New BindingSource
    Dim dbConn As New ConnectionSQL
    Public Function CreateDataHisKeluarga(ByVal hiskel As Enthistory_keluarga) As Boolean
        QueryKandidat = "insert into [histori_keluarga] (id_kandidat,nm_istri_suami, nm_anak1, nm_anak2, nm_anak3, usia_istri_suami, usia_anak1, usia_anak2, usia_anak3, pend_istri_suami, pend_anak1, pend_anak2,  pend_anak3, pek_istri_suami, pek_anak1, pek_anak2, pek_anak3)"
        QueryKandidat += "values('{0}', '{1}', '{2}', '{3}', '{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}','{12}','{13}','{14}','{15}','{16}')"
        QueryKandidat = String.Format(QueryKandidat, hiskel.IDKandidat, hiskel.NamaIstriAtuSuami, hiskel.NamaAnak1, hiskel.NamaAnak2, hiskel.NamaAnak3, hiskel.UsiaIstriSuami, hiskel.UsiaAnak1, hiskel.UsiaAnak2, hiskel.UsiaAnak3, hiskel.PendidikanIstriSuami, hiskel.PendidikanAnak1, hiskel.PendidikanAnak2, hiskel.PendidikanAnak3, hiskel.PekertjaanIstriSuami, hiskel.PekerjaanAnak1, hiskel.PekerjaanAnak2, hiskel.PekerjaanAnak3)
        Return dbConn.jalankanQuery(QueryKandidat)
    End Function

    Public Function UpdateDataHisKeluarga(ByVal hiskel As Enthistory_keluarga) As Boolean
        QueryKandidat = "update [histori_keluarga] set  nm_istri_suami = '{0}', "
        QueryKandidat += "nm_anak1 = '{1}', "
        QueryKandidat += "nm_anak2 = '{2}', "
        QueryKandidat += "nm_anak3 = '{3}', "
        QueryKandidat += "usia_istri_suami = '{4}', "
        QueryKandidat += "usia_anak1 = '{5}', "
        QueryKandidat += "usia_anak2 = '{6}', "
        QueryKandidat += "usia_anak3 = '{7}', "
        QueryKandidat += "pend_istri_suami = '{8}', "
        QueryKandidat += "pend_anak1 = '{9}', "
        QueryKandidat += "pend_anak2 = '{10}', "
        QueryKandidat += "pend_anak3 = '{11}', "
        QueryKandidat += "pek_istri_suami = '{12}', "
        QueryKandidat += "pek_anak1 = '{13}', "
        QueryKandidat += "pek_anak2 = '{14}', "
        QueryKandidat += "pek_anak3 = '{15}'"
        QueryKandidat += "where id_kandidat = '{16}'"

        QueryKandidat = String.Format(QueryKandidat, hiskel.NamaIstriAtuSuami, hiskel.NamaAnak1, hiskel.NamaAnak2, hiskel.NamaAnak3, hiskel.UsiaIstriSuami, hiskel.UsiaAnak1, hiskel.UsiaAnak2, hiskel.UsiaAnak3, hiskel.PendidikanIstriSuami, hiskel.PendidikanAnak1, hiskel.PendidikanAnak2, hiskel.PendidikanAnak3, hiskel.PekertjaanIstriSuami, hiskel.PekerjaanAnak1, hiskel.PekerjaanAnak2, hiskel.PekerjaanAnak3, hiskel.IDKandidat)
        Return dbConn.jalankanQuery(QueryKandidat)
    End Function

    Public Function Delete(ByVal kode As String) As Boolean
        QueryKandidat = "delete from [histori_keluarga] where id_kandidat = '{0}'"
        QueryKandidat = String.Format(QueryKandidat, kode)
        Return dbConn.jalankanQuery(QueryKandidat)
    End Function

    Public Function findBykode(ByVal kode As String) As Enthistory_keluarga
        If kode <> "" Then
            QueryKandidat = "select * from histori_keluarga  where id_kandidat = '{0}'"
            QueryKandidat = String.Format(QueryKandidat, kode)
            Try
                dt = dbConn.bukaTable(QueryKandidat)
            Catch ex As Exception
                MessageBox.Show(ex.ToString())
            End Try
            'Tab 2
            hisKel.NamaIstriAtuSuami = dt.Rows(0)(0).ToString().Trim()
            hisKel.NamaAnak1 = dt.Rows(0)(1).ToString().Trim()
            hisKel.NamaAnak2 = dt.Rows(0)(2).ToString().Trim()
            hisKel.NamaAnak3 = dt.Rows(0)(3).ToString().Trim()
            hisKel.UsiaIstriSuami = dt.Rows(0)(4).ToString().Trim()
            hisKel.UsiaAnak1 = dt.Rows(0)(5).ToString().Trim()
            hisKel.UsiaAnak2 = dt.Rows(0)(6).ToString().Trim()
            hisKel.UsiaAnak3 = dt.Rows(0)(7).ToString().Trim()
            hisKel.PendidikanIstriSuami = dt.Rows(0)(8).ToString().Trim()
            hisKel.PendidikanAnak1 = dt.Rows(0)(9).ToString().Trim()
            hisKel.PendidikanAnak2 = dt.Rows(0)(10).ToString().Trim()
            hisKel.PendidikanAnak3 = dt.Rows(0)(11).ToString().Trim()
            hisKel.PekertjaanIstriSuami = dt.Rows(0)(12).ToString().Trim()
            hisKel.PekerjaanAnak1 = dt.Rows(0)(13).ToString().Trim()
            hisKel.PekerjaanAnak2 = dt.Rows(0)(14).ToString().Trim()
            hisKel.PekerjaanAnak3 = dt.Rows(0)(15).ToString().Trim()
            hisKel.IDKandidat = dt.Rows(0)(16).ToString().Trim()

            'Tab 3


        End If

        Return hisKel
    End Function

End Class
